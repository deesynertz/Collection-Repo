<?php
session_start();
require_once('../config/connect.php');

if (!isset($_SESSION['id']) && $_SESSION['role'] !== 'user') {
  header("location: ../login.php");
}

?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>Track Days Page</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Jumbotron Template for Bootstrap</title>
  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="../styles/stylesheet.css">

  <link rel="stylesheet" href="../styles/bootstrap.min.css">
  <link rel="stylesheet" href="../plugins/fullcalendar/main.css">

  <style>
    .inside-dashboard {
      margin-bottom: 50px;
    }

    .dashboard {
      margin-bottom: 50px;
    }

    a {
      color: purple;
    }

    a:hover {
      color: teal;
    }
  </style>


</head>

<body>
  <nav class="navbar navbar-expand-md navbar-light bg-light fixed-top">
    <a class="navbar-brand" href="#"><img src="../images/logo.png" width="30" height="30" alt="This is Logo" class="logo-brand"> Women flo</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExampleDefault">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="dashboard.php">Dashboard <span class="sr-only">(current)</span></a>
        </li>
      </ul>

      <div class="form-inline my-2 my-lg-0">

        <a class="btn btn-outline-success my-2 my-sm-0 mx-2" href="profile.php">Profile</a>
        <a class="btn btn-outline-info my-2 my-sm-0" href="../logout.php">Logout</a>
      </div>
    </div>
  </nav>

  <main role="main">

    <!-- Main jumbotron for a primary marketing message or call to action -->

      <div class="container" style="margin-top: 20px;">

        <h3 class="display-5">
          </h1>

          <div class="row">

          <div class="dashboard">

            <div class="col-12 col-md-6 col-lg-3 inside-dashboard">
              <a href="trackdays.php">
                <div class="">
                  <img src="../images/calendars.png" alt="my photo" class="dash-photo">
                  <div style="margin-left: 8px; margin-right: 4px; text-align:center; color:purple">
                    TRACK DAYS
                  </div>
                </div>
              </a>
            </div>

            <div class="col-12 col-md-6 col-lg-3 inside-dashboard">
              <a href="ask.php">
                <div>
                  <img src="../images/chats.png" alt="my photo" class="dash-photo">
                  <div style="margin-left: 8px; margin-right: 4px; text-align:center; color:purple">
                    ASK QUESTION
                  </div>
                </div>
              </a>
            </div>

            <div class="col-12 col-md-6 col-lg-3 inside-dashboard">
              <a href="#">
                <div>
                  <img src="../images/profile.png" alt="my photo" class="dash-photo">
                  <div style="margin-left: 8px; margin-right: 4px; text-align:center; color:purple">
                    PROFILE
                  </div>
                </div>
              </a>
            </div>

            <div class="col-12 col-md-6 col-lg-3 inside-dashboard">
              <a href="info.php">
                <div>
                  <img src="../images/setting.png" alt="my photo" class="dash-photo">
                  <div style="margin-left: 8px; margin-right: 4px; text-align:center; color:purple">
                    USEFUL INFO.
                  </div>
                </div>
              </a>
            </div>

            <div class="col-12 col-md-6 col-lg-3 inside-dashboard">
              <a href="#">
                <div>
                  <img src="../images/setting.png" alt="my photo" class="dash-photo">
                  <div style="margin-left: 8px; margin-right: 4px; text-align:center; color:purple">
                    MY CHATTINGS.
                  </div>
                </div>
              </a>
            </div>
          </div>
          </div>
      </div>
    
  </main>

  <footer class="container">
    <p>&copy; 2021, Women Flo</p>
  </footer>

  <script src="../plugins/jquery/jquery.min.js"></script>
  <script src="../plugins/jquery-ui/jquery-ui.min.js"></script>
  <script src="../plugins/fullcalendar/main.js"></script>