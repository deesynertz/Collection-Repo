<?php
session_start();
require_once('../config/connect.php');

if (!isset($_SESSION['id']) && $_SESSION['role'] !== 'user') {
  header("location: ../login.php");
}

?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Track Days Page</title>

  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="../styles/stylesheet.css">

  <link rel="stylesheet" href="../styles/bootstrap.min.css">
  <link rel="stylesheet" href="../plugins/fullcalendar/main.css">


</head>

<body>

  <nav class="navbar navbar-expand-md navbar-light bg-light fixed-top">
    <a class="navbar-brand" href="#"><img src="../images/logo.png" width="30" height="30" alt="This is Logo" class="logo-brand"> Women flo</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExampleDefault">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="dashboard.php">Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="trackdays.php">Track days</a>
        </li>

        <li class="nav-item">
          <a class="nav-link active" href="info.php">View Info <span class="sr-only">(current)</span></a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="ask.php">FAQ</a>
        </li>
      </ul>

      <div class="form-inline my-2 my-lg-0">

        <a class="btn btn-outline-success my-2 my-sm-0 mx-2" href="profile.php">Profile</a>
        <a class="btn btn-outline-info my-2 my-sm-0" href="../logout.php">Logout</a>
      </div>
    </div>
  </nav>

  <main role="main">

    <div class="jumbotron" style="margin-top: 20px;">
      <div class="container">

        <h3 class="display-5"></h3>

        <div class="row">
          <div id="div1">
            <div id="div2">
              <h2>Factors that cause irregular Menstrual cycle</h2>
            </div>
          </div>

          <ol>

            <li>Pregnancy</li>
            <p>If you miss a period or notice changes in your period and you’ve had sex,
              you can take a pregnancy test at home or see your doctor to find out if you’re pregnant <br>
              Pregnancy can cause you to miss your period or experience spotting. Other symptoms of early pregnancy may include:</p>
            <ul>
              <li>morning sickness</li>
              <li>Nausea</li>
              <li>Fatigue</li>
              <li>breast tingling or tenderness</li>
              <li>sensitivity to smells</li>
            </ul>
            <p>If you may be pregnant and experience sharp, stabbing pain in the pelvis or abdomen that lasts more than a few minutes,
              see your doctor right away to rule out ectopic pregnancy or miscarriage.</p>

            <li>Hormonal birth control</li>
            <p>Hormonal birth control pills and hormone-containing intrauterine devices (IUDs) can cause irregular bleeding. <br>
              Birth control pills may cause spotting between periods and result in much lighter periods. An IUD may cause heavy bleeding.</p>


            <li>Breastfeeding</li>
            <p>Prolactin is a hormone that’s responsible for breast milk production. Prolactin suppresses your reproductive hormones resulting in very light periods
              or no period at all while you’re breastfeeding. <br>
              Your periods should return shortly after you stop breastfeeding. Read on to learn more the effects of breastfeeding on your period.</p>


            <li>Perimenopause</li>
            <p>Perimenopause is the transition phase before you enter menopause. It usually begins in your 40s, but can occur earlier.
              You may experience signs and symptoms lasting from 4 to 8 years, beginning with changes to your menstrual cycle.
              Fluctuating estrogen levels during this time can cause your menstrual cycles to get longer or shorter. <br>

              Other signs and symptoms of perimenopause include:
            <ul>
              <li>hot flashes</li>
              <li>night sweats</li>
              <li>mood changes</li>
              <li>difficulty sleeping</li>
              <li>vaginal dryness</li>
            </ul>
            </p>

            <li>Polycystic ovary syndrome (PCOS)</li>
            <p>Irregular periods are the most common sign of PCOS.
              If you have PCOS, you may miss periods and have heavy bleeding when you do get your period. <br>
              PCOS can also cause
            <ul>
              <li>infertility</li>
              <li>excess facial and body hair</li>
              <li>weight gain or obesity</li>
              <li>male-pattern baldness</li>
            </ul>

            </p>

            <li>Thyroid problems</li>
            <p>
              An underactive thyroid may cause longer, heavier periods. <br>
              A 2015 study found that 44 percent of participants with menstrual irregularities also had thyroid disorders,<br>
              Hypothyroidism, or underactive thyroid, can cause longer, heavier periods and increased cramping. You may also experience fatigue, sensitivity to cold, and weight gain. <br>
              High levels of thyroid hormones, which is seen in hyperthyroidism, can cause shorter, lighter periods. You may also experience <br>
            <ul>
              <li>anxiety and nervousness</li>
              <li>heart palpitations</li>
              <li>sudden weight loss</li>
            </ul>
            Swelling at the base of your neck is another common sign of a thyroid disorder
            </p>
            <li>Uterine fibroids</li>
            <p>
              Fibroids are muscular tumors that develop in the wall of the uterus.
              Most fibroidsTrusted Source are noncancerous and can range in size from as small as an apple seed to the size of a grapefruit.
              Fibroids can cause your periods to be very painful and heavy enough to cause anemia. <br>
              You may also experience:
            <ul>
              <li>pelvic pain or pressure</li>
              <li>low back pain</li>
              <li>pain in your legs</li>
              <li>pain during sex</li>

            </ul>
            (OTC) pain Most fibroids don’t require treatment and symptoms can be managed with over-the-counter medications and an iron supplement if you develop anemia.
            </p>


            <li>Endometriosis</li>
            <p>
              Endometriosis affects 1 in 10 women of reproductive age. This is a condition in which the tissue that normally lines your uterus grows outside the uterus. <br>
              Endometriosis causes very painful, even debilitating menstrual cramps. Endometriosis also causes heavy bleeding, prolonged periods, and bleeding between periods. <br>
              Other symptoms may include:
            <ul>
              <li>gastrointestinal pain</li>
              <li>painful bowel movements</li>
              <li>pain during and after intercourse</li>
              <li>infertility</li>
            </ul>
            Exploratory surgery is the only way to diagnose endometriosis. There’s currently no cure for the condition, but symptoms can be managed with medication or hormone therapy.
            </p>

            <li>Being overweight</li>
            <p>
              Obesity is known to cause menstrual irregularity. ResearchTrusted Source shows that being overweight impacts hormone and insulin levels, which can interfere with your menstrual cycle. <br>
              Rapid weight gain can also cause menstrual irregularities. Weight gain and irregular periods are common signs of PCOS and hypothyroidism, and should be evaluated by your doctor. <br>

            </p>


            <li>Extreme weight loss and eating disorders</li>
            <p>
              Excessive or rapid weight loss can cause your period to stop. Not consuming enough calories can interfere with the production of the hormones needed for ovulation.
              You’re considered underweight if you have a body mass index lower than 18.5. Along with stopped periods, you may also experience fatigue, headaches, and hair loss
              See your doctor if
            <ul>
              <li>you’re underweight</li>
              <li>have lost a lot of weight without trying</li>
              <li>you have an eating disorder</li>
            </ul>
            </p>
            <li>Excessive exercise</li>
            <p>Intense or excessive exercise has been shown to interfere with the hormones responsible for menstruation. <br>
              Female athletes and women who participate in intensive training and physical activities, such as ballet dancers, often develop amenorrhea, which is missed or stopped periods.
              Cutting back on your training and increasing your calorie count can help restore your periods.
            </p>
            <li>Stress</li>
            <p>Research shows that stress can interfere with your menstrual cycle by temporarily interfering with the part of the brain that controls the hormones that regulate your cycle. Your periods should return to normal after your stress decreases. Try these 16 techniques to relieve your stress</p>

            <li>Medications</li>
            <p>Certain medications can interfere with your menstrual cycle, including
            <ul>
              <li>blood thinners</li>
              <li>thyroid medications</li>
              <li>epilepsy drugs</li>
              <li>antidepressants</li>
              <li>chemotherapy drugs</li>
              <li>hormone replacement therapy</li>
            </ul>
            Speak to your doctor about changing your medication
            </p>
            <li>Cervical and endometrial cancer</li>
            <p>
              Cervical and endometrial cancers can cause changes to your menstrual cycle, along with bleeding between periods or heavy periods. Bleeding during or after intercourse and unusual discharge are other signs and symptoms of these cancers <br>
            </p>
            <p>Remember that these symptoms are more commonly caused by other issues. Speak to your doctor if you’re concerned.</p>
          </ol>

          <h3>When to call your healthcare provider</h3>
          <p>There are several possible causes of irregular periods, many of which require medical treatment.
            Make an appointment to see your doctor if:
          <ul>
            <li>your periods stop for more than 3 months and you’re not pregnant</li>
            <li>your periods become irregular suddenly</li>
            <li>you have a period that lasts longer than 7 days</li>
            <li>you need more than one pad or tampon every hour or two</li>
            <li>you develop severe pain during your period</li>
            <li>your periods are less than 21 days or more than 35 days apart</li>
            <li>you experience spotting between periods</li>
            <li>you experience other symptoms, such as unusual discharge or fever</li>
          </ul>
          </p>

          <p>
            Your doctor will ask about your medical history and want to know about
          <ul>
            <li>any stress or emotional issues you’re experiencing</li>
            <li>any changes to your weight</li>
            <li>your sexual history</li>
            <li>how much you exercise</li>
          </ul>
          Medical tests may also be used to help diagnose the cause of your irregular bleeding, including:
          <ul>
            <li>a pelvic examination</li>
            <li>blood tests</li>
            <li>abdominal ultrasound</li>
            <li>pelvic and transvaginal ultrasound</li>
            <li>CT scan</li>
            <li>MRI</li>
          </ul>

          </p>


          <h3>Treatments</h3>
          <p> Treatment depends on what’s causing your irregular periods and may require treating an underlying medical condition. <br>
            Your doctor may recommend one or more of the following treatments:
          <ul>
            <li>oral contraceptives</li>
            <li>hormonal IUDs</li>
            <li>thyroid medication</li>
            <li>metformin</li>
            <li>weight loss or weight gain</li>
            <li>exercise</li>
            <li>vitamin D supplements</li>
          </ul>
          Stress reduction techniques may also help, including:
          <ul>
            <li>yoga</li>
            <li>meditation</li>
            <li>deep breathing</li>
            <li>cutting back on work and other demands</li>
          </ul>
          </p>

        </div>
      </div>
    </div>

  </main>

  <footer class="container">
    <p>&copy; 2021, Women Flo</p>
  </footer>

  <script src="../plugins/jquery/jquery.min.js"></script>
  <script src="../plugins/jquery-ui/jquery-ui.min.js"></script>
  <script src="../plugins/fullcalendar/main.js"></script>



</body>

</html>