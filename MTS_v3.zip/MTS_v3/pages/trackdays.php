<?php

require_once('../config/backend-script.php');

if (!isset($_SESSION['id']) && $_SESSION['role'] !== 'user') {
    header("location: ../login.php");
}

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Days Page</title>

    <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="../styles/stylesheet.css">

    <link rel="stylesheet" href="../styles/bootstrap.min.css">
    <link rel="stylesheet" href="../plugins/fullcalendar/main.css">

    <style>
        .text-orange {
            color: #ff851b !important
        }

        a.text-orange:focus,
        a.text-orange:hover {
            color: #ff851b !important
        }

        .text-pink {
            color: #e83e8c !important
        }

        a.text-pink:focus,
        a.text-pink:hover {
            color: #e83e8c !important
        }
    </style>


</head>

<body>

    <nav class="navbar navbar-expand-md navbar-light bg-light fixed-top">
        <a class="navbar-brand" href="#"><img src="../images/logo.png" width="30" height="30" alt="This is Logo" class="logo-brand"> Women flo</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="trackdays.php">Track days <span class="sr-only">(current)</span></a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="info.php">View Info</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="ask.php">FAQ</a>
                </li>
            </ul>

            <div class="form-inline my-2 my-lg-0">

                <a class="btn btn-outline-success my-2 my-sm-0 mx-2" href="profile.php">Profile</a>
                <a class="btn btn-outline-info my-2 my-sm-0" href="../logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <main role="main">

        <!-- Main jumbotron for a primary marketing message or call to action -->
        <div class="jumbotron" style="margin-top: 25px;">
            <div class="container">

                <!-- ALERT START -->
                <?php if (!empty($succMessage)) : ?>
                    <div class='alert alert-success msg-alert'><small><strong>[SUCCESS]:</strong> <?php echo $succMessage; ?></small></div>
                <?php elseif (!empty($warnMessage)) : ?>
                    <div class='alert alert-warning msg-alert'><small><strong>[WARNING]:</strong> <?php echo $warnMessage; ?></small></div>
                <?php elseif (!empty($erroMessage)) : ?>
                    <div class='alert alert-danger msg-alert'><small><strong>
                                [ERROR]:</strong> <?php echo $erroMessage; ?></small></div>
                <?php endif; ?>
                <!-- ALERT END -->

                <div class="row">



                    <div class="col-md-3">
                        <div class="sticky-top mb-3">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">Track your Period</h3>
                                </div>



                                <form method="POST" action="trackdays.php">
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label for="length">Starting Date</label>
                                            <input id="periodStart" type="date" required name="periodStart" class="form-control" placeholder="Starting Period">
                                        </div>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-12 col-lg-6">
                                                    <label for="length">Length</label>
                                                    <input id="length" type="number" required name="length" class="form-control" placeholder="e.g 4">
                                                </div>
                                                <div class="col-12 col-lg-6">
                                                    <label for="cycle">Your cicle</label>
                                                    <input id="cycle" type="number" required name="cycle" class="form-control" placeholder="e.g 28">
                                                </div>
                                            </div>

                                        </div>
                                        <div class="form-group">
                                            <input type="submit" name="track" value="Submit" class="btn btn-info btn-block btn-flat">
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <br>
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">Color</h3>
                                </div>
                                <div class="card-body">
                                    <div class="btn-group" style="width: 100%; margin-bottom: 7px;">
                                        <ul class="fc-color-picker" id="color-chooser">
                                            <span><a class="text-danger" href="javascript:void(0)"><i class="fas fa-square"></i></a>&nbsp; Period</span>
                                            <span><a class="text-primary" href="javascript:void(0)"><i class="fas fa-square"></i></a>&nbsp; Low</span>
                                            <span><a class="text-success" href="javascript:void(0)"><i class="fas fa-square"></i></a>&nbsp; High</span> <br>

                                            <span><a class="text-orange" href="javascript:void(0)"><i class="fas fa-square"></i></a>&nbsp; Boy</span>

                                            <span><a class="text-pink" href="javascript:void(0)"><i class="fas fa-square"></i></a>&nbsp; Girl</span>

                                        </ul>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="col-md-9">
                        <div class="card card-primary">
                            <div class="card-body" class="calender-card-body">
                                <!-- calender render position -->
                                <div id="calendar" class="calender-point"></div>
                                <!-- end calender render position -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="container">
        <p>&copy; 2021, Women Flo</p>
    </footer>

    <script src="../plugins/jquery/jquery.min.js"></script>
    <script src="../plugins/jquery-ui/jquery-ui.min.js"></script>
    <script src="../plugins/fullcalendar/main.js"></script>

    <script>
        function ini_events(ele) {
            ele.each(function() {
                var eventObject = {
                    title: $.trim($(this).text())
                }
                $(this).data('eventObject', eventObject)
            })
        }

        var eventCb = [];

        ini_events($('#external-events div.external-event'));

        /* -------------------initialize the calendar ---------------- */
        var Calendar = FullCalendar.Calendar;
        var calendarEl = document.getElementById('calendar');

        /* ------------------initialize the external events ---------- */
        //fetch data
        function fetchData() {
            var user_id = '<?php echo $_SESSION['id']; ?>';
            $.ajax({
                url: "../config/backend-script.php?user_id=" + user_id,
                type: "POST",
                cache: false,
                dataType: "json",
                success: function(response) {
                    if (response.empty) {
                        renderCalender();
                    } else {
                        // console.log(response);
                        prepareEvents(response);
                    }
                }
            })
        }

        /* -- execute function to fetch data from the database ------- */
        fetchData();

        function prepareEvents(data) {
            var date = new Date(data['start_p']);
            var d = date.getDate(), // Day
                m = date.getMonth(), // Month
                y = date.getFullYear(); // Year

            var length = parseInt(data['length']),
                cycle = parseInt(data['cycle'])
                highRate = 8,
                preHighRate = 10;

            // period event
            var StartPeriodDate = new Date(y, m, d),
                periodEndDate = new Date(y, m, (d + length));
            periodEvnt = {
                title: 'PERIOD (' + length + ') days',
                start: StartPeriodDate,
                end: periodEndDate,
                backgroundColor: '#dc3545', // Red
                borderColor: '#dc3545', // Red
                allDay: true
            }

            // low chance event
            var startlowChanceDate = periodEndDate,
                lowChanceEndDate = new Date(y, m, (d + preHighRate));
            lowChanceEvnt = {
                title: 'LOW CHANCE (' + (preHighRate - length) + ') days',
                start: startlowChanceDate,
                end: lowChanceEndDate,
                backgroundColor: '#0073b7', // Blue
                borderColor: '#0073b7', // Blue
                allDay: true
            }

            // High Chance  event
            var startHighChanceDate = lowChanceEndDate,
                highChanceEndDate = new Date(y, m, (d + preHighRate + highRate));
            highChanceEvnt = {
                title: 'HIGH CHANCE (' + highRate + ') days',
                start: startHighChanceDate,
                end: highChanceEndDate,
                backgroundColor: '#00a65a', // Green
                borderColor: '#00a65a', // Green
                allDay: true
            }

            // High Chance event (GIRL)
            var girlHighChanceStart = new Date(y, m, (d + preHighRate) + 1),
                girlHighChanceEnd = new Date(y, m, (d + preHighRate) + 3);
            girlHighChanceEvnt = {
                title: 'HIGH CHANCE (Girl high posibility)',
                start: girlHighChanceStart,
                end: girlHighChanceEnd,
                backgroundColor: '#e83e8c ', // Pink //yellow #f39c12
                borderColor: '#e83e8c ', // Pink //yellow #f39c12
                allDay: true
            }

            var boyHighChanceStart = girlHighChanceEnd,
                boyHighChanceEnd = new Date(y, m, (d + preHighRate) + 6);
            boyHighChanceEvnt = {
                title: 'HIGH CHANCE (boy high posibility)',
                start: boyHighChanceStart,
                end: boyHighChanceEnd,
                backgroundColor: '#ff851b', // Orange
                borderColor: '#ff851b', // Orange
                allDay: true
            }


            // calc the deffence between starting point to high chance event
            const diffDays = Math.ceil((highChanceEndDate - StartPeriodDate) / (1000 * 60 * 60 * 24));

            // low chance event
            // Determine days remain before next period based on cycle
            var lowChance2StartDate = highChanceEndDate,
                remaindays = (cycle - parseInt(diffDays)),
                lowChance2EndDate = new Date(y, m, ((d + preHighRate + highRate) + remaindays));

            lowChance2Evnt = {
                title: 'LOW CHANCE (' + (cycle - parseInt(diffDays)) + ') days',
                start: lowChance2StartDate,
                end: lowChance2EndDate,
                backgroundColor: '#0073b7', // Blue
                borderColor: '#0073b7', // Blue
                allDay: true
            }

            // call the function to show the calender
            renderCalender();
        
        }

        function renderCalender() {
            var eventsListAll = [];
            var eventsListAll = [
                periodEvnt, // Period
                lowChanceEvnt, // low chance 1st 
                highChanceEvnt, // High Chance
                girlHighChanceEvnt, // girl 
                boyHighChanceEvnt, // boy
                lowChance2Evnt // low Chance 2nd
            ];

            // var eventsList = (periodEvnt) ? eventsListAll : [];
            var calendar = new Calendar(calendarEl, {
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                },
                themeSystem: 'bootstrap',
                events: eventsListAll,
            });

            calendar.render(); // render the calender

        }
    </script>
</body>

</html>