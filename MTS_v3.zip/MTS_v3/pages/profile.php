<?php
session_start();
require_once('../config/connect.php');

if (!isset($_SESSION['id']) && $_SESSION['role'] !== 'user') {
  header("location: ../login.php");
}

?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Track Days Page</title>

  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="../styles/stylesheet.css">

  <link rel="stylesheet" href="../styles/bootstrap.min.css">
  <link rel="stylesheet" href="../plugins/fullcalendar/main.css">


</head>

<body>

  <nav class="navbar navbar-expand-md navbar-light bg-light fixed-top">
    <a class="navbar-brand" href="#"><img src="../images/logo.png" width="30" height="30" alt="This is Logo" class="logo-brand"> Women flo</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExampleDefault">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="dashboard.php">Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="trackdays.php">Track days</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="info.php">View Info</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="chats.php">Chattings</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="ask.php">FAQ</a>
        </li>
      </ul>

      <div class="form-inline my-2 my-lg-0">

        <a class="btn btn-outline-success my-2 my-sm-0 mx-2" href="profile.php">Profile</a>
        <a class="btn btn-outline-info my-2 my-sm-0" href="../logout.php">Logout</a>
      </div>
    </div>
  </nav>

  <main role="main">
    <div class="jumbotron" style="margin-top: 20px;">
      <div class="container">

        <h3 class="display-5"></h3>

        <div class="row">

         


          
        </div>
      </div>
    </div>

  </main>

  <footer class="container">
    <p>&copy; 2021, Women Flo</p>
  </footer>

  <script src="../plugins/jquery/jquery.min.js"></script>
  <script src="../plugins/jquery-ui/jquery-ui.min.js"></script>
  <script src="../plugins/fullcalendar/main.js"></script>



</body>

</html>