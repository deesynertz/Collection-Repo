<?php
require_once('../config/backend-script.php');

if (!isset($_SESSION['id']) && $_SESSION['role'] !== 'user') {
  header("location: ../login.php");
}

?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>Track Days Page</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Jumbotron Template for Bootstrap</title>
  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="../styles/stylesheet.css">

  <link rel="stylesheet" href="../styles/bootstrap.min.css">
  <link rel="stylesheet" href="../plugins/fullcalendar/main.css">

  <style>
    .inside-dashboard {
      margin-bottom: 50px;
    }

    .dashboard {
      margin-bottom: 50px;
    }

    a {
      color: purple;
    }

    a:hover {
      color: teal;
    }
  </style>


</head>

<body>
  <nav class="navbar navbar-expand-md navbar-light bg-light fixed-top mb-4">
    <a class="navbar-brand" href="#"><img src="../images/logo.png" width="30" height="30" alt="This is Logo" class="logo-brand"> Women flo</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExampleDefault">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="dashboard.php">Dashboard <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="trackdays.php">Track days <span class="sr-only">(current)</span></a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="info.php">View Info</a>
        </li>

        <li class="nav-item">
          <a class="nav-link active" href="ask.php">FAQ</a>
        </li>
      </ul>

      <div class="form-inline my-2 my-lg-0">

        <a class="btn btn-outline-success my-2 my-sm-0 mx-2" href="profile.php">Profile</a>
        <a class="btn btn-outline-info my-2 my-sm-0" href="../logout.php">Logout</a>
      </div>
    </div>
  </nav>

  <main role="main" class="container mt-6">
    <div class="jumbotron mt-4">
      <h3>Frequentry Asked Question</h3>

      <div class="row">

        <!-- ALERT START -->
        <?php if (!empty($succMessage)) : ?>
          <div class='col-12 alert alert-success msg-alert'><small><strong>[SUCCESS]:</strong> <?php echo $succMessage; ?></small></div>
        <?php elseif (!empty($warnMessage)) : ?>
          <div class='col-12 alert alert-warning msg-alert'><small><strong>[WARNING]:</strong> <?php echo $warnMessage; ?></small></div>
        <?php elseif (!empty($erroMessage)) : ?>
          <div class='col-12 alert alert-danger msg-alert'><small><strong>
                [ERROR]:</strong> <?php echo $erroMessage; ?></small></div>
        <?php endif; ?>
        <!-- ALERT END -->


        <div class="card col-12">
          <form class="form-horizontal" action="ask.php" method="POST">
            <div class="form-group pt-2">
              <label for="question py-2">Your Question</label>

              <textarea class="form-control" id="question" name="question" placeholder=""></textarea>

            </div>
            <div class="form-group row mb-5">
              <div class="offset-sm-2 col-sm-10">
                <input type="submit" value="Submit" name="askQuestion" class="btn btn-danger float-right w-25">
              </div>
            </div>
          </form>

        </div>

        <div class="clearfix col-12"></div>
        <!-- Post -->
        <div class="card col-12 mt-3" id="postList"></div>
      </div>



    </div>
  </main>

  <footer class="container">
    <p>&copy; 2021, Women Flo</p>
  </footer>

  <script src="../plugins/jquery/jquery.min.js"></script>
  <script src="../plugins/jquery-ui/jquery-ui.min.js"></script>
  <script src="../plugins/fullcalendar/main.js"></script>

  <script>
    $(document).ready(function() {
      fetchAllQuestions();

      function fetchAllQuestions() {
        var params = 'allQuestions';

        $.ajax({
          url: "../config/backend-script.php?FAQ=" + params,
          type: "POST",
          cache: false,
          dataType: "json",
          success: function(data) {
            var post = '';
            if (!data.empty) {
              $('#postList').html("");
              data.forEach(element => {
                post += `
                <div class="pb-2">
                  <div class="user-block pt-4 pb-2">
                    <span class="username"><a class="text-info">Mis. ${element['username']}</a></span>
                    <span class="description">Shared - ${element['askedOn']}</span>
                  </div>
                  <p>
                    ${element['question']} <br><br>

                    <a href="javascript:void(0)" id="commentView"  value="${element['quizID']}" class="link-black text-sm mr-2"><i class="far fa-comments mr-1"></i></i>Comments ${(element['comments'] > 0) ? `(${element['comments']})` : ''}<small></small></a>

                    <div class="pb-1 pl-5" id="answersList${element['quizID']}"></div>

                  </p>

                  <div class="pl-5">
                    <form class="form-horizontal" action="" method="POST">
                      <div class="input-group input-group-sm mb-0">
                      <input type="hidden" name="quizID" value="${element['quizID']}">
                        <input required class="form-control form-control-sm" name="answerInput" placeholder="Answer">
                        <div class="input-group-append">
                          <input type="submit" class="btn btn-info" value="comment" name="sendAnswer">
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              `;
              });

              $('#postList').html(post);
            }
          }
        });
      }


      $(document).on('click', '#commentView', function(){
        var quizID = $(this).attr('value');
        $.ajax({
          url: "../config/backend-script.php?quizID=" + quizID,
          type: "POST",
          cache: false,
          dataType: "json",
          success: function(AnswerResponse) {
            var oneAnswer = "";
            if (!AnswerResponse.empty) {

              $('#answersList'+quizID).html("");
              AnswerResponse.forEach(ansObj => {

                console.log(ansObj);
                oneAnswer += `
                  <div class="user-block pt-3 pb-2">
                    <span class="username"><a class="text-info">Mis. ${ansObj['username']}</a></span>
                    <span class="description">Shared - ${ansObj['answeredOn']}</span>
                  </div>
                  <p> ${ansObj['answer']} </p>
                `;

                
              });

              $('#answersList'+quizID).html(oneAnswer);
            }


            
          }
        });
      });

    });
  </script>

</body>

</html>