<?php
require_once('../config/connect.php');
// if (!isset($_SESSION['id']) && $_SESSION['role'] !== 'user') {
//     header("location: ../login.php");
// }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/bootstrap.min.css">
    <link rel="stylesheet" href="../styles/style.css">
    <title>User - Dashboard</title>
</head>

<body>
    <header>
        <div class="div-header">
            <div style="margin-top: 12px;"><img src="../images/logo.png" alt="This is Logo" class="logo-brand"></div>
            <center style="border-bottom: thin solid #fff; display:flex; justify-content:start" class="center">
                <h2>Women flo,<span style="font-style: italic; font-size:small">(where women enjoy their days)</span></h2>
            </center>
        </div>
        <div class="nav">
            <a href="../logout.php">Logout</a>
        </div>
    </header>
    <main class="main-dash">
        <!-- <div style="width: 100%;">
            <center style="border-bottom: thin solid #d6d6d6; font-weight:bolder">DASHBOARD</center>
        </div> -->
        <div>
            <div class="dashboard">
                <div class="inside-dashboard">
                    <a href="trackdays.php">
                        <div>
                            <img src="../images/calendars.png" alt="my photo" class="dash-photo">
                            <div style="margin-left: 8px; margin-right: 4px; text-align:center; color:purple">
                                TRACK DAYS
                            </div>
                        </div>
                    </a>
                </div>
                <div class="inside-dashboard">
                    <a href="ask.php">
                        <div>
                            <img src="../images/chats.png" alt="my photo" class="dash-photo">
                            <div style="margin-left: 8px; margin-right: 4px; text-align:center; color:purple">
                                ASK QUESTION
                            </div>
                        </div>
                    </a>
                </div>
                <div class="inside-dashboard">
                    <a href="#">
                        <div>
                            <img src="../images/profile.png" alt="my photo" class="dash-photo">
                            <div style="margin-left: 8px; margin-right: 4px; text-align:center; color:purple">
                                PROFILE
                            </div>
                        </div>
                    </a>
                </div>
                <div class="inside-dashboard">
                    <a href="info.php">
                        <div>
                            <img src="../images/setting.png" alt="my photo" class="dash-photo">
                            <div style="margin-left: 8px; margin-right: 4px; text-align:center; color:purple">
                                USEFUL INFO.
                            </div>
                        </div>
                    </a>
                </div>
                <div class="inside-dashboard">
                    <a href="chats.php">
                        <div>
                            <img src="../images/setting.png" alt="my photo" class="dash-photo">
                            <div style="margin-left: 8px; margin-right: 4px; text-align:center; color:purple">
                                MY CHATTINGS.
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </main>
    <footer>All rights reseved &copy;2021, Womenflo@gmail.com</footer>
</body>
<style>
    .inside-dashboard {
        margin-bottom: 50px;
    }

    .dashboard {
        margin-bottom: 50px;
    }
    
    a{
        color: purple;
    }

    a:hover{
        color: teal;
    }
</style>

</html>