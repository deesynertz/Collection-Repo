<?php
session_start();
require_once('../config/connect.php');
// if (!isset($_SESSION['id']) && $_SESSION['role'] !== 'user') {
//     header("location: ../login.php");
// }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/bootstrap.min.css">
    <link rel="stylesheet" href="../styles/style.css">
    <title>Ask Question</title>
</head>

<body>
    <header>
        <div class="div-header">
            <div style="margin-top: 12px;"><img src="../images/logo.png" alt="This is Logo" class="logo-brand"></div>
            <center style="border-bottom: thin solid #fff; display:flex; justify-content:start" class="center">
                <h2>Women flo,<span style="font-style: italic; font-size:small">(where women enjoy their days)</span></h2>
            </center>
        </div>
        <div class="nav">
            <div class="dropdown">
                <a href="#" class="dropbtn btn" id="drop" onclick="set()">Navigations
                    <i class="fa fa-caret-down"></i>
                </a>
                <div class="dropdown-content" id="content">
                    <a href="dashboard.php">Dashboard</a>
                    <a href="trackdays.php">Track days</a>
                    <a href="chats.php">Chattings</a>
                    <a href="info.php">View Info</a>
                    <a href="#">Profile</a>
                    <a href="../logout.php">Logout</a>
                </div>
            </div>
        </div>
    </header>
    <main class="main-dash">
        <div style="width: 100%;">
            <center style="border-bottom: thin solid #d6d6d6; font-weight:bolder">Ask Question</center>
        </div>
        <div style="display:flex; justify-content:center; align-items:center; min-height:50vh">
            <form action="ask.php" method="post">
                <?php
                    if(isset($_POST['send'])){
                        $ask = mysqli_real_escape_string($con, $_POST['ask']);
                        $sql = "INSERT INTO questions (question, user_id) VALUES ('$ask', '$_SESSION[id]')";
                        $query = mysqli_query($con, $sql);
                        if(!mysqli_error($con)){
                            echo "<div class='alert alert-success'><strong>[SUCCESS]:</strong> Question Sent.</div>";
                            header("Refresh: 2;");
                        }else{
                            echo "<div class='alert alert-danger'><strong>[ERROR]:</strong> Something Went Wrong, Try Again.</div>";
                        }
                    }
                ?>
                <div class="form-group row">
                    <div class="col-12">
                        <label>Put your Qn here:</label>
                        <!-- <input class="form-control" type="password" required placeholder="Password" name="password"> -->
                        <textarea name="ask" id="" cols="130" rows="3" class="form-control" required></textarea>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-12 text-right">
                        <button type="submit" class="btn btn-ghost" name="send">SEND</button>
                    </div>
                </div>
            </form>
        </div>
    </main>
    <footer>All rights reseved &copy;2021, Womenflo@gmail.com</footer>
</body>
<style>
    form {
        box-shadow: 0 0 0 #fff;
        width: 60%;
    }

    .btn {
        background-color: purple;
        color: #fff;
        width: 15%;
        letter-spacing: 2px;
    }

    .btn:hover {
        background-color: #fff;
        border: thin solid purple;
        color: purple;
    }
    .dropbtn{
        width: 100%;
        background-color: #fff;
        border: thin solid purple;
        color: purple;
    }
</style>
<script src="../styles/dropdown.js"></script>
</html>