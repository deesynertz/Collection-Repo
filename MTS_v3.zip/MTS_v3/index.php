<?php
require_once('config/connect.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/bootstrap.min.css">
    <link rel="stylesheet" href="styles/style.css">
    <title>Homepage</title>
</head>

<body class="body">
    <section>
        <!-- <aside>
            <img src="images/logo.jpeg" alt="This is Logo" class="logo">
        </aside> -->
        <div class="main">
            <div style="display: flex; justify-content:start;align-items:center; margin-bottom:12px">
                <div><img src="images/logo.png" alt="This is Logo" class="logo"></div>
                <center style="border-bottom: thin solid purple;">
                    <h2>Women flo,<span style="font-style: italic; font-size:small;">(where women enjoy their days)</span></h2>
                </center>
            </div>
            <div class="index-list">
                <li>In this simple system you will be helped accurately to track your period</li>
                <li>But also you will get some educational informations on menstruation cycle matters</li>
                <li>Whenever you get some inquires about the system or other things related to menstrual cycle
                    periods, the system provided to you a simple chat that will allow you to ask and get answers
                    at the moment from the specialists.</li>
                <li>Use the system today and get enjoy your menstrual cycle periods happily</li>
            </div>
            <div class="dropdown">
                <a href="login.php" class="dropbtn btn">Get Started</a>
            </div>
    </section>
    <footer style="background: none; color: purple">
        All rights reseved &copy;2021, Womenflo@gmail.com
    </footer>
</body>
<style>
    .logo {
        border-radius: 0;
        box-shadow: 0 0 0 #fff;
    }

    .body {
        color: purple;
        /* background: #ffffff; */
    }

    footer {
        color: purple;
    }

    .main {
        border-bottom: thin solid transparent;
    }

    .index-list {
        width: 60%;
    }

    .dropdown {
        width: 100%;
        display: flex;
        justify-content: center;
        margin-bottom: 20px;
    }

    .dropbtn {
        width: 15%;
        background-color: purple;
        border: thin solid purple;
        color: #fff;
        border-radius: 20px;
    }

    .dropbtn:hover {
        background-color: transparent;
        color: purple;
    }
</style>

</html>