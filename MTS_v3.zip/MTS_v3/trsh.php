<script>
    $(function() {
        /* ---------------initialize the external events ------------*/
        function ini_events(ele) {
            ele.each(function() {
                var eventObject = {
                    title: $.trim($(this).text())
                }
                $(this).data('eventObject', eventObject)
            })
        }

        ini_events($('#external-events div.external-event'))

        /* -------------------initialize the calendar ---------------- */
        var Calendar = FullCalendar.Calendar;
        var calendarEl = document.getElementById('calendar');

        /* ------------------initialize the external events ---------- */
        //fetch data
        function fetchData() {
            var user_id = '<?php echo $_SESSION['id']; ?>';
            $.ajax({
                url: "../config/backend-script.php?user_id=" + user_id,
                type: "POST",
				cache: false,
				dataType: "json",
                success: function(response) {

                    console.log(response);
                    // response.forEach(element => {
                    //     prepareData(element);
                    // });

                    prepareData(response);
                }
            })
        }

        /* -- execute function to fetch data from the database ------- */
        fetchData();

        /* --------------------- Set events ------------------ */
        function prepareData(data) {
            listOfMultipleMonth = [];
            data.forEach(element => {
                // prepareData(element);
                console.log(element);
                var startPeriod = element[0],
                    length = parseInt(element[1]),
                    cycle = parseInt(element[2]),
                    highRate = 8,
                    preHighRate = 10;

                // console.log(startPeriod['length']);


                var date = new Date(startPeriod);
                var d = date.getDate(), // Day
                    m = date.getMonth(), // Month
                    y = date.getFullYear(); // Year

                // period event
                var StartPeriodDate = new Date(y, m, d),
                    periodEndDate = new Date(y, m, (d + length));
                periodEvnt = {
                    title: 'PERIOD (' + length + ') days',
                    start: StartPeriodDate,
                    end: periodEndDate,
                    backgroundColor: '#dc3545', // Red
                    borderColor: '#dc3545', // Red
                    allDay: true
                }

                // low chance event
                var startlowChanceDate = periodEndDate,
                    lowChanceEndDate = new Date(y, m, (d + preHighRate));
                lowChanceEvnt = {
                    title: 'LOW CHANCE (' + (preHighRate - length) + ') days',
                    start: startlowChanceDate,
                    end: lowChanceEndDate,
                    backgroundColor: '#0073b7', // Blue
                    borderColor: '#0073b7', // Blue
                    allDay: true
                }

                // High Chance  event
                var startHighChanceDate = lowChanceEndDate,
                    highChanceEndDate = new Date(y, m, (d + preHighRate + highRate));
                highChanceEvnt = {
                    title: 'HIGH CHANCE (' + highRate + ') days',
                    start: startHighChanceDate,
                    end: highChanceEndDate,
                    backgroundColor: '#00a65a', // Green
                    borderColor: '#00a65a', // Green
                    allDay: true
                }

                // High Chance event (GIRL)
                var girlHighChanceStart = new Date(y, m, (d + preHighRate) + 1),
                    girlHighChanceEnd = new Date(y, m, (d + preHighRate) + 3);
                girlHighChanceEvnt = {
                    title: 'HIGH CHANCE (Girl high posibility)',
                    start: girlHighChanceStart,
                    end: girlHighChanceEnd,
                    backgroundColor: '#e83e8c ', // Pink //yellow #f39c12
                    borderColor: '#e83e8c ', // Pink //yellow #f39c12
                    allDay: true
                }

                var boyHighChanceStart = girlHighChanceEnd,
                    boyHighChanceEnd = new Date(y, m, (d + preHighRate) + 6);
                boyHighChanceEvnt = {
                    title: 'HIGH CHANCE (boy high posibility)',
                    start: boyHighChanceStart,
                    end: boyHighChanceEnd,
                    backgroundColor: '#ff851b', // Orange
                    borderColor: '#ff851b', // Orange
                    allDay: true
                }


                // calc the deffence between starting point to high chance event
                const diffDays = Math.ceil((highChanceEndDate - StartPeriodDate) / (1000 * 60 * 60 * 24));

                // low chance event
                // Determine days remain before next period based on cycle
                var lowChance2StartDate = highChanceEndDate,
                    remaindays = (cycle - parseInt(diffDays)),
                    lowChance2EndDate = new Date(y, m, ((d + preHighRate + highRate) + remaindays));

                lowChance2Evnt = {
                    title: 'LOW CHANCE (' + (cycle - parseInt(diffDays)) + ') days',
                    start: lowChance2StartDate,
                    end: lowChance2EndDate,
                    backgroundColor: '#0073b7', // Blue
                    borderColor: '#0073b7', // Blue
                    allDay: true
                }


                // call the function to show the calender
                reanderCalender();

            });
        }

        // SET CALENDER
        function reanderCalender() {
            const eventsList = [
                periodEvnt, // Period
                lowChanceEvnt, // low chance 1st 
                highChanceEvnt, // High Chance
                girlHighChanceEvnt, // girl 
                boyHighChanceEvnt, // boy
                lowChance2Evnt // low Chance 2nd
            ];

            // add event in calender instance
            var calendar = new Calendar(calendarEl, {
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                },
                themeSystem: 'bootstrap',
                events: ((periodEvnt === null) ? [] : eventsList),
                /* will show calender even if no data set in current month */
            });

            calendar.render(); // render the calender
        }
    });
</script>





        <!-- <div class="main-section">
            <form class="mt-5" method="post" action="trackdays.php">
            <?php

if (isset($_POST['track'])) {

    $date = mysqli_real_escape_string($con, $_POST['date']);
    $sql = "INSERT INTO period_day (bleed_date) VALUES ('$date')";
    $res = mysqli_query($con, $sql);

    $period_id = mysqli_insert_id($con);

    if (!mysqli_error($con)) {

        $sql = "SELECT * FROM period_day WHERE bleed_date = '$date'";
        $res = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($res);
        $period = $row['bleed_date'];

        $date2 = date_create($period);
        date_add($date2, date_interval_create_from_date_string('4 days'));
        $date2 = $date2->format('Y-m-d');

        $date3 = date_create($period);
        date_add($date3, date_interval_create_from_date_string('8 days'));
        $date3 = $date3->format('Y-m-d');

        $date4 = date_create($period);
        date_add($date4, date_interval_create_from_date_string('25 days'));
        $date4 = $date4->format('Y-m-d');

        $date5 = date_create($period);
        date_add($date5, date_interval_create_from_date_string('29 days'));
        $date5 = $date5->format('Y-m-d');

        $sql = "INSERT INTO period_period (id, period, low_chance, high_chance, low_last_chance, user_id) 
            VALUES ('$period_id', '$date2','$date3', '$date4', '$date5', '".$_SESSION['id']."')";
        $query = mysqli_query($con, $sql);
        if (!$query) {
            die(mysqli_error($con));
        }
        if (!mysqli_error($con)) {
            echo 'success';
        }
    } else {
        die(mysqli_error($con));
    }
}
?>

<div class="form-header">
    <div>
        <h6>First menstrual day</h6>
    </div>
</div>
<div class="inside-form">
    <div class="form-group row">
        <div class="col-12">
            <label>Username</label>
            <input class="form-control" type="date" required name="date">
        </div>
    </div>
    <div class="form-group row">
        <div class="col-12 text-center">
            <button type="submit" class="btn btn-ghost" name="track">Track Days</button>
            <p></p>
            <p>
            <p></p>
            </p>
        </div>
    </div>
</div>
</form>
</div> -->

<!--codes to show the days that has been tracked -->
<section class="mt-4">
<div class="row">
<div class="col-12 mb-3">
    <div class="text-center"><span class="title" style="font-size:40px; font-weight:bold;">
            <u>PERIOD DAYS</u></span></div>
</div>
<div class="col-12 offset-md-1 col-md-10">
    <table class="table table-bordered table-sm">
        <tr>
            <th style="background-color:#ff9999; color:white; text-align:center; font-size: 20px">
                PERIOD</th>
            <th style="background-color:#98fb98; color:white; text-align:center; font-size: 20px">
                LOW CHANCE</th>
            <th style="background-color:#6495ed; color:white; text-align:center; font-size: 20px">
                HIGH CHANCE</th>
            <th style="background-color:#98fb98; color:white; text-align:center; font-size: 20px">
                LOW CHANCE</th>
        </tr>
        <?php
        // Fetch all the periods of a partivu;sr woman from the database and display them
        $sql = "SELECT * FROM period_day, period_period, users WHERE users.id = 1";

        $result = mysqli_query($con, $sql);
        if (!mysqli_error($con)) {
            if (mysqli_num_rows($result) > 0) {
                
                while ($row = mysqli_fetch_assoc($result)) {

        ?>
                    <tr>
                        <td style="background-color:#ff9999; color:white;"><?php
                            echo $row['bleed_date'] . ' to ' . $row['period']; ?></td>
                        <td style="background-color:#98fb98; color:white;"><?php
                            echo $row['period'] . ' to ' . $row['low_chance']; ?></td>
                        <td style="background-color:#6495ed; color:white;"><?php
                            echo $row['low_chance'] . ' to ' . $row['high_chance']; ?></td>
                        <td style="background-color:#98fb98; color:white;"><?php
                            echo $row['high_chance'] . ' to ' . $row['low_last_chance']; ?></td>
                    </tr>
        <?php
                }
            } else {
                echo "<tr><td colspan=5>No days to show</td></tr>";
            }
        }
        ?>
    </table>
</div>
</div>
</section> 