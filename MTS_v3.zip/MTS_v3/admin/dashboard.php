<?php
session_start();
require_once('../config/connect.php');
// if (!isset($_SESSION['id']) && $_SESSION['role'] !== 'admin') {
//     header("location: ../login.php");
// }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/bootstrap.min.css">
    <link rel="stylesheet" href="../styles/style.css">
    <title>User - Dashboard</title>
</head>

<body>
    <header>
        <div class="div-header">
            <div style="margin-top: 12px;"><img src="../images/logo.png" alt="This is Logo" class="logo-brand"></div>
            <center style="border-bottom: thin solid #fff; display:flex; justify-content:start" class="center">
                <h2>Women flo,<span style="font-style: italic; font-size:small">(where women enjoy their days)</span></h2>
            </center>
        </div>
        <div class="nav">
            <a href="../logout.php">Logout</a>
        </div>
    </header>
    <main class="main-dash">
        <div style="width: 100%;">
            <center style="border-bottom: thin solid #d6d6d6; font-weight:bolder">DASHBOARD - Asked Questions</center>
        </div>
        <div style="margin-bottom: 50px; display:flex; flex-direction: column">
            <?php
            $sql = "SELECT * FROM questions ORDER BY date";
            $query = mysqli_query($con, $sql);
            if (!mysqli_error($con)) {
                if (mysqli_num_rows($query) > 0) {
                    while ($row = mysqli_fetch_array($query)) {
                        $id = $row
            ?>
                        <div class="ask-me">
                            <div class="asked-qn">
                                <?php echo $row['question']; ?>
                            </div>
                            <!-- <div class="dropdown">
                                <a href="answer.php?id=<?php echo $row['id']; ?>" class="dropbtn btn">Reply</a>
                            </div> -->
                            <div class="dropdown">
                                <a href="answer.php?id=<?php echo $row['id']; ?>" class="dropbtn btn">Reply</a>
                            </div>
                        </div>
            <?php
                    }
                }
            } else {
                echo "<div class='alert alert-danger'><strong>[ERROR]:</strong> Something went wrong, Try again.</div>";
            }
            ?>
        </div>
    </main>
    <footer>All rights reseved &copy;2021, Womenflo@gmail.com</footer>
</body>
<style>
    .inside-dashboard {
        margin-bottom: 50px;
    }

    .dashboard {
        margin-bottom: 50px;
    }

    a {
        color: purple;
    }

    a:hover {
        color: teal;
    }

    .ask-me {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: flex-start;
        margin-top: 20px;
        width: 100%;
        border-bottom: thin solid #d6d6d6;
    }

    .asked-qn {
        width: 100%;
        border-radius: 5px;
        margin-left: 23px;
        margin-bottom: 4px;
    }

    .main-dash>div {
        border-left: thin solid transparent;
        border-right: thin solid transparent;
    }


    .dropdown {
        width: 100%;
        display: flex;
        justify-content: start;
        margin: 4px 0 12px 20px;
    }

    .dropbtn {
        width: 8%;
        background-color: transparent;
        border: thin solid purple;
        color: purple;
        border-radius: 25px;
    }

    .dropbtn:hover {
        background-color: purple;
        color: #fff;
    }
</style>

</html>