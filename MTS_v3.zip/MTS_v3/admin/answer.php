<?php
session_start();
require_once('../config/connect.php');
// if (!isset($_SESSION['id']) && $_SESSION['role'] !== 'admin') {
//     header("location: ../login.php");
// }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/bootstrap.min.css">
    <link rel="stylesheet" href="../styles/style.css">
    <title>Answer Questions - Page</title>
</head>

<body>
    <header>
        <div class="div-header">
            <div style="margin-top: 12px;"><img src="../images/logo.png" alt="This is Logo" class="logo-brand"></div>
            <center style="border-bottom: thin solid #fff; display:flex; justify-content:start" class="center">
                <h2>Women flo,<span style="font-style: italic; font-size:small">(where women enjoy their days)</span></h2>
            </center>
        </div>
        <div class="nav">
            <div class="dropdown">
                <a href="#" class="dropbtn btn" id="drop" onclick="set()">Navigations
                    <i class="fa fa-caret-down"></i>
                </a>
                <div class="dropdown-content" id="content">
                    <a href="dashboard.php">Dashboard</a>
                    <a href="#">Profile</a>
                    <a href="../logout.php">Logout</a>
                </div>
            </div>
        </div>
    </header>
    <?php
        if(isset($_GET['id']) && !empty($_GET['id'])){
            $id = mysqli_real_escape_string($con, $_GET['id']);
            $sql = "SELECT id FROM questions WHERE id = '$id'";
            $result = mysqli_query($con, $sql);
            if(!mysqli_error($con)){
                if(mysqli_num_rows($result) > 0 ){
                    $row = mysqli_fetch_array($result);
                    $_SESSION['qn'] = $row['id'];
                }
            }
        }
    ?>
    <main class="main-dash">
        <div style="width: 100%;">
            <center style="border-bottom: thin solid #d6d6d6; font-weight:bolder">Answer Enquiries</center>
        </div>
        <div style="display:flex; justify-content:center; align-items:center; min-height:50vh">
            <form action="answer.php" method="post">
                <?php
                    if(isset($_POST['send'])){
                        $ans = mysqli_real_escape_string($con, $_POST['answer']);
                        $sql = "INSERT INTO answers (answer, question_id, user_id) VALUES ('$ans', '$_SESSION[qn]', 1)";
                        $result = mysqli_query($con, $sql);
                        if(!mysqli_error($con)){
                            echo "<div class='alert alert-success'><strong>[SUCCESS]:</strong> Reply Sent.</div>";
                            header("Refresh: 2;");
                        }
                    }
                ?>
                <div class="form-group row">
                    <div class="col-12">
                        <label>Put Ans here:</label>
                        <!-- <input class="form-control" type="password" required placeholder="Password" name="password"> -->
                        <textarea name="answer" id="" cols="130" rows="3" class="form-control" required></textarea>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-12 text-right">
                        <button type="submit" class="btn btn-ghost" name="send">SEND</button>
                    </div>
                </div>
            </form>
        </div>
    </main>
    <footer>All rights reseved &copy;2021, Womenflo@gmail.com</footer>
</body>
<style>
    form {
        box-shadow: 0 0 0 #fff;
        width: 60%;
    }

    .btn {
        background-color: purple;
        color: #fff;
        width: 15%;
        letter-spacing: 2px;
    }

    .btn:hover {
        background-color: #fff;
        border: thin solid purple;
        color: purple;
    }
    .dropbtn{
        width: 100%;
        background-color: #fff;
        border: thin solid purple;
        color: purple;
    }
</style>
<script src="../styles/dropdown.js"></script>
</html>