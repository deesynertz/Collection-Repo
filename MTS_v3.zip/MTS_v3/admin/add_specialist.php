<?php
require_once('../config/connect.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/bootstrap.min.css">
    <link rel="stylesheet" href="../styles/style.css">
    <title>Add Specialist</title>
</head>

<body>
    <header>
        <div class="div-header">
            <div style="margin-top: 12px;"><img src="../images/logo.png" alt="This is Logo" class="logo-brand"></div>
            <center style="border-bottom: thin solid #fff; display:flex; justify-content:start" class="center">
                <h2>Women flo,<span style="font-style: italic; font-size:small">(where women enjoy their days)</span></h2>
            </center>
        </div>
        <div class="nav">
            <div class="dropdown">
                <a href="../index.php" class="dropbtn btn">Home</a>
            </div>
            <div class="dropdown" style="margin-left: 12px">
                <a href="../logout.php" class="dropbtn btn">Logout</a>
            </div>
        </div>
    </header>
    <main>
        <form class="mt-5" method="post" action="add_specialist.php">
            <?php
            if (isset($_POST['register'])) {
                $username = mysqli_real_escape_string($con, $_POST['username']);
                $phone = mysqli_real_escape_string($con, $_POST['phone']);
                $pass = mysqli_real_escape_string($con, $_POST['pass']);

                $sql = "INSERT INTO users (username, phone, password, role_id) VALUES ('$username', '$phone', sha1('$pass'), 2)";
                $query = mysqli_query($con, $sql);

                if (!mysqli_error($con)) {
                    echo "<div class='alert alert-success'><strong>[SUCCESS]:</strong> Registration done Successfully.</div>";
                    header("Refresh: 2;");
                } else {
                    echo "<div class='alert alert-danger'><strong>[ERROR]:</strong> Something went wrong, Try again.</div>";
                }
            }
            ?>
            <div class="form-header">
                <center style="background-color: transparent;" class="center">
                    <img src="../images/logo.png" alt="my logo" class="logo-brand logoform">
                </center>
            </div>
            <div class="inside-form">
                <div class="form-group row">
                    <div class="col-6">
                        <label>Username</label>
                        <input class="form-control" type="text" required placeholder="Username" name="username">
                    </div>
                    <div class="col-6">
                        <label>Phone Number</label>
                        <input class="form-control" type="number" required placeholder="Phone number" name="phone">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-12">
                        <label>Password</label>
                        <input class="form-control" type="password" required placeholder="Password" name="pass">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-12 text-right">
                        <button type="submit" class="btn btn-ghost" name="register">Register</button>
                    </div>
                </div>
            </div>
        </form>
    </main>
    <footer>
        All rights reseved &copy;2021, Womenflo@gmail.com
    </footer>
</body>
<style>
    .btn {
        background-color: purple;
        color: #fff;
    }

    .btn:hover {
        background-color: #fff;
        border: thin solid purple;
        color: purple;
    }

    a {
        color: purple;
    }

    a:hover {
        color: teal;
    }
    .dropbtn {
        width: 100%;
        background-color: #fff;
        border: thin solid purple;
        color: purple;
    }

    .dropbtn:hover {
        background: purple;
        color: #fff;
    }
</style>

</html>