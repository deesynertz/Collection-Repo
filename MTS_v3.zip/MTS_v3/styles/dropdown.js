function set() {
  if (document.getElementById("drop")) {
    document.getElementById("content").style.display = "block";
  }
}
