<?php
require_once('config/backend-script.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/bootstrap.min.css">
    <link rel="stylesheet" href="styles/style.css">
    <title>Register Page</title>
    <style>
        .btn {
            background-color: purple;
            color: #fff;
        }

        .btn:hover {
            background-color: #fff;
            border: thin solid purple;
            color: purple;
        }

        a {
            color: purple;
        }

        a:hover {
            color: teal;
        }

        .dropbtn {
            width: 100%;
            background-color: #fff;
            border: thin solid purple;
            color: purple;
        }

        .dropbtn:hover {
            background: purple;
            color: #fff;
        }
    </style>
</head>

<body>
    <main>
        <form class="mt-5" method="post" action="register.php">
            <div class="form-header pt-7">
                <center style="background-color: transparent;">
                    <img src="images/logo.png" alt="my logo" class="logo-brand logoform">
                    <h3>Women flo</h3>
                </center>
            </div>

            <div class="inside-form">
                <?php if (!empty($success_message) || !empty($error_message)) : ?>
                    <?php if (!empty($success_message)) : ?>
                        <div class='alert alert-success pb-0'>
                            <p><small><strong>[SUCCESS]:</strong> <?php echo $success_message; ?></small></p>
                        </div>
                    <?php else : ?>
                        <div class='alert alert-danger pb-0'>
                            <p><small><strong>[ERROR]:</strong> <?php echo $error_message; ?></small></p>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                <div class="form-group row">
                    <div class="col-6">
                        <label>Username</label>
                        <input class="form-control" type="text" required placeholder="Enter Username" name="username">
                    </div>
                    <div class="col-6">
                        <label>Phone Number</label>
                        <input class="form-control" type="number" required placeholder="Phone number" name="phone">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-12">
                        <label>Password</label>
                        <input class="form-control" type="password" required placeholder="Password" name="pass">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-12 text-right">
                        <button type="submit" class="btn btn-ghost w-100" name="register">Register</button>
                    </div>
                </div>
                <span style="text-align: center; font-style: italic; font-size: 14px;">
                    Already Registerd? <a href="login.php">Login</a>
                </span>
            </div>
        </form>
    </main>
    <footer>
        All rights reseved &copy;2021, Womenflo@gmail.com
    </footer>
</body>

</html>