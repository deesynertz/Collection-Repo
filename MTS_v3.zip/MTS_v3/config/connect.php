<?php
$con = mysqli_connect("localhost", "root", "", "period_track_db");
if (mysqli_error($con)) {
    die('Failed to connect to the Database');
}
