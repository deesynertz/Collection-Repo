<?php 
  session_start();
  require_once('connect.php');


$error_message   = '';
$success_message = '';
$succMessage = '';
$warnMessage = '';
$erroMessage = '';


if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $pass = mysqli_real_escape_string($con, $_POST['pass']);

    $sql = "SELECT users.id, users.username, users.phone, roles.name as role FROM users, roles 
            WHERE users.role_id = roles.id 
            AND username = '$username' 
            AND password = sha1('$pass')";
    $query = mysqli_query($con, $sql);

    if (!mysqli_error($con)) {
        if (mysqli_num_rows($query) > 0) {
            $row = mysqli_fetch_array($query);
            $_SESSION['loggedIn'] = TRUE;
            $_SESSION['id'] = $row['id'];
            $_SESSION['role'] = $row['role'];
            $_SESSION['username'] = $row['username'];

            if ($_SESSION['role'] == 'admin') {
                header("Refresh: 2; url=admin/add_specialist.php");
            } else if ($_SESSION['role'] == 'user') {
                $success_message = 'Login done Successfully.';
                header("Refresh: 2; url=pages/dashboard.php");
            } else if ($_SESSION['role'] == 'women_specialist') {
                $success_message = 'Login done Successfully.';
                header("Refresh: 2; url=specialist/dashboard.php");
            }
        } else {
            $error_message   = 'User Doesnot Exist, please register first.';
        }
    } else {
        $error_message   = 'Something went wrong, Try again.';
    }
}

if (isset($_POST['register'])) {
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    $pass = mysqli_real_escape_string($con, $_POST['pass']);

    $sql = "INSERT INTO users (username, phone, password, role_id) VALUES ('$username', '$phone', sha1('$pass'), 3)";
    $query = mysqli_query($con, $sql);

    if (!mysqli_error($con)) {
        $success_message = 'Registration done Successfully.';
        header("Refresh: 2; url=login.php");
    } else {
        $error_message   = 'Something went wrong, Try again.';
    }
}

if (isset($_GET['user_id'])) {
    $prepareSqlQuery = "SELECT start_p, length, cycle FROM period_details p JOIN users u ON 
    p.user_id = u.id WHERE user_id = '" . $_GET['user_id'] . "' ORDER BY p.ID DESC";
    $resultQuery = mysqli_query($con, $prepareSqlQuery);

    if (mysqli_num_rows($resultQuery) > 0) {
        // $data = $resultQuery->fetch_all();
        $data = $resultQuery->fetch_assoc();
    } else {
        $data = array('empty' => 'No data');
    }

    echo json_encode($data);
}

if (isset($_POST['track'])) {
    // input variable
    $user_id        = $_SESSION['id'];
    $periodStart    = mysqli_real_escape_string($con, $_POST['periodStart']);
    $length         = mysqli_real_escape_string($con, $_POST['length']);
    $cycle          = mysqli_real_escape_string($con, $_POST['cycle']);

    if ($length < 3) {
        $warnMessage = "Length must be atleast 3 day !";
    } else if ($cycle < 28 || $cycle > 31) {
        $warnMessage = "Cycle Range from 28 -31 days";
    } else {
        // check if data arleady exist before submiting
        $existQuery = "SELECT * FROM period_details WHERE user_id = '".$user_id."' AND MONTH(start_p) = EXTRACT(MONTH FROM '".$periodStart."');";
        $resutl = mysqli_query($con, $existQuery);


        if (mysqli_num_rows($resutl) > 0) {
            // exist
            $row = mysqli_fetch_assoc($resutl);
            $dbMonth = date("m", strtotime($periodStart));
            $fmMonth = date("m", strtotime($row['start_p']));
            $prevStartDate = $row['start_p'];
            $prevStartlenght = $row['length'] + 1;
            $dateAfterLenght = date('Y-m-d', strtotime($prevStartDate. +$prevStartlenght.'days'));

            if ($dbMonth == $fmMonth) {
                if (strtotime($prevStartDate) == strtotime($periodStart)) {
                    $erroMessage = "You can't Submit identical date!";
                } else if (strtotime($periodStart) <= strtotime($dateAfterLenght)) {
                    $erroMessage = "You cant submit next event within " . ($prevStartlenght + (round($prevStartlenght / 2) - 3)) . " days";
                } else  {
                    // now its oky then, call function toadd data
                    $callBack = insertData($con, $user_id, $periodStart, $length, $cycle);

                    if ($callBack > 0) {
                        $succMessage = "Successfully Set.";
                    } else {
                        $erroMessage = "Something went wrong !!";
                    }
                }
            }else {
                $callBack = insertData($con, $user_id, $periodStart, $length, $cycle);
                if ($callBack > 0) {
                    $succMessage = "Successfully Set.";
                } else {
                    $erroMessage = "Something went wrong !!";
                }
            }
        } else {
            // not exist then, call function toadd data
            $callBack = insertData($con, $user_id, $periodStart, $length, $cycle);
            if ($callBack > 0) {
                $succMessage = "Successfully Set.";
            } else {
                $erroMessage = "Something went wrong !!";
            }
        }
    }
}

function insertData($con, $user_id, $periodStart, $length, $cycle) {
    $prepareSqlQuery = "INSERT INTO period_details (user_id, start_p, length, cycle) 
    VALUES ('$user_id', '$periodStart', '$length', '$cycle')";
    $resQuery = mysqli_query($con, $prepareSqlQuery);
    $response = mysqli_insert_id($con); // if data inserted successfuly will retuen last id
    // show message accordingly
    return $response;
}

// ASK QUESTION
if (isset($_POST['askQuestion'])) {
    if (empty($_POST['question'])) {
        $warnMessage = "Please Write you question in textarea";
    }else {
        $user_id   = $_SESSION['id'];
        $question  = mysqli_real_escape_string($con, $_POST['question']);
        // insert

        $insertSQ = "INSERT INTO questions(question, user_id) VALUE('".$question."','".$user_id."')";
        $resutlCallBack = mysqli_query($con, $insertSQ);

        if (mysqli_insert_id($con) > 0) {
            $succMessage = "Your Question Sent Successful";
        }else {
            $erroMessage = "Something went wrong !!";
        } 
    }
}

// ANSWER QUESTION

if(isset($_POST['sendAnswer'])) {
    $user_id     = $_SESSION['id'];
    $quizID = mysqli_real_escape_string($con, $_POST['quizID']);
    $answer      = mysqli_real_escape_string($con, $_POST['answerInput']);
    // insert

    $insertAnswerSQL = "INSERT INTO answers(answer,question_id,user_id) VALUES('".$answer."','".$quizID."','".$user_id."')";
    $insertAnswerResult = mysqli_query($con, $insertAnswerSQL);

    if (mysqli_insert_id($con) > 0) {
        $succMessage = "Your Answer Sent Successful";
        // $succMessage = $user_id;
    }else {
        $erroMessage = "Something went wrong !!";
    } 
}



// FETCH QUESTIONS
if (isset($_GET['FAQ']) == 'allQuestions') {

    $prepareSqlQuery = "SELECT q.id AS quizID, phone, question, username, askedOn,(SELECT COUNT(*) FROM answers WHERE q.id = question_id GROUP BY question_id) AS comments FROM  questions q JOIN users u ON q.user_id = u.id ORDER BY q.id DESC";
    $resultQuery = mysqli_query($con, $prepareSqlQuery);

    if (mysqli_num_rows($resultQuery) > 0) {
        $data = $resultQuery->fetch_all(MYSQLI_ASSOC);
    } else {
        $data = array('empty' => 'No data');
    }

    echo json_encode($data);
}

// FETCH ANSWER BELONGS TO QUESTION

if (isset($_GET['quizID'])) {
    if (!empty($_GET['quizID'])) {

        $answersSql = "SELECT u.id userID, username, qn.id quizID,answeredOn, ans.id ansID, answer FROM answers ans RIGHT JOIN questions qn ON qn.id = question_id JOIN users u ON u.id = qn.user_id WHERE question_id ='".$_GET['quizID']."'";
        $answersResult = mysqli_query($con, $answersSql);

        if (mysqli_num_rows($answersResult) > 0) {
            $data = $answersResult->fetch_all(MYSQLI_ASSOC);
        } else {
            $data = array('empty' => 'Comment');
        }
    }else {
        $data = array('empty' => 'Comment');
    }

    echo json_encode($data);
}



  