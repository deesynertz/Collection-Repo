<?php
session_start();
require_once('ows_database/das.php');

if ($_SESSION['loged_in'] != TRUE) {
    header("location: login.php");
}


if ($_SESSION['loged_in_role'] == 1) {
    header("location: ows_admin.php");
}


$userID = $_SESSION['loged_in_user_id'];

if (isset($_POST['sold_item'])) {
    $sold_item = "UPDATE items SET is_sold=1 WHERE item_id='" . $_POST['item_id_sold'] . "'";
    mysqli_query($ows_conn, $sold_item);
}

if (isset($_GET['itemID'])) {
    $itemID = $_GET['itemID'];
    $select_item = "SELECT start_time, countdown, item_name, icst_name,item_img_name, item_id, price, icat_name, IFNULL((SELECT MAX(currentPrice) FROM bid_tb WHERE bid_tb.item_id = items.item_id GROUP BY item_id), 0) abid, (SELECT endTime FROM bid_tb WHERE bid_tb.item_id = items.item_id GROUP BY item_id) as endTime, (SELECT user_id FROM bid_tb WHERE bid_tb.item_id = items.item_id GROUP BY item_id) as presedBy, (SELECT bid_status FROM bid_tb WHERE bid_tb.item_id = items.item_id GROUP BY item_id) as bid_status, (SELECT id FROM bid_tb WHERE bid_tb.item_id = items.item_id GROUP BY item_id) as bidID FROM items JOIN item_cats ON items.item_cat=item_cats.icat_id JOIN item_cat_status ON items.item_cat_stat=item_cat_status.icst_id JOIN item_image ON items.item_id=item_image.item WHERE items.user!='" . $userID . "' AND item_id = '" . $itemID . "'";
    $data_item = mysqli_query($ows_conn, $select_item);

    $item = mysqli_fetch_assoc($data_item);

    $imageURL = 'ows_item_img/' . $item["item_img_name"];

    if ($item["icst_name"] == 'new') {
        $icst_badge = 'bg-green';
    } else if ($item["icst_name"] == 'used') {
        $icst_badge = 'bg-red';
    } else {
        $icst_badge = 'bg-yellow';
    }

    // add countdown intocurrent dateTime
    if (!empty($item['abid'])) {
        $endTime = $item['endTime'];
    }
}

$error_msg = '';
if (isset($_POST['bido'])) {

    $url = 'display.php?itemID=' . $_GET['itemID'];

    // check if is bid is less than price
    if ($_POST['price'] >= $_POST['bid']) {
        // message not allowed
        $error_msg = 'Enter higher price!!';
    } else {
        if ($_POST['currBid'] >= $_POST['bid']) {
            // message not allowed
            $error_msg = 'Enter higher price!!';
        } else {
            // good to go
            $bid = $_POST['bid'];

            if (!empty($item['abid'])) {
                // check if present bid is for you
                if ($item['presedBy'] == $userID) {
                    // is you the update price
                    $setValueEndTime = date_format(date_create(date("D M d, Y G:i:s", strtotime(date("D M d, Y G:i:s")) + (($item['countdown'] * 60) + (60 * 60)))), 'Y-m-d H:i:s');

                    $updateAbid = "UPDATE bid_tb SET currentprice='" . $bid . "', endTime = '" . $setValueEndTime . "' WHERE item_id='" . $item['item_id'] . "' AND user_id = '" . $userID . "'";
                    $run = mysqli_query($ows_conn, $updateAbid);

                    if (mysqli_affected_rows($ows_conn) > 0) {
                        $data = array('success' => 'successfully');
                        $endTime = $setValueEndTime;
                        // header("location: '".$url."'");

                    } else {
                        $data = array('error' => 'sowething went wrong in update');
                    }
                } else {
                    // not you insert your bid
                    $setValueEndTime = date_format(date_create(date("D M d, Y G:i:s", strtotime(date("D M d, Y G:i:s")) + (($item['countdown'] * 60) + (60 * 60)))), 'Y-m-d H:i:s');
                    var_dump('not you insert your bid');
                    // var_dump($setValueEndTime);
                    $insertAbid = "INSERT INTO bid_tb(item_id,currentPrice,user_id,endTime) VALUE('" . $item['item_id'] . "','" . $bid . "','" . $userID . "','" . $setValueEndTime . "')";
                    if (mysqli_query($ows_conn, $insertAbid)) {
                        $data = array('success' => 'successfully');
                        $endTime = $setValueEndTime;
                        // header("location: '".$url."'");

                    } else {
                        $data = array('error' => 'sowething went wrong in insert (2)');
                    }
                }
            } else {

                // insert new bid
                $setValueEndTime = date_format(date_create(date("D M d, Y G:i:s", strtotime(date("D M d, Y G:i:s")) + (($item['countdown'] * 60) + (60 * 60)))), 'Y-m-d H:i:s');
                $insertAbid = "INSERT INTO bid_tb(item_id,currentPrice,user_id,endTime) VALUE('" . $item['item_id'] . "','" . $bid . "','" . $userID . "','" . $setValueEndTime . "')";
                if (mysqli_query($ows_conn, $insertAbid)) {
                    $data = array('success' => 'successfully');
                    $endTime = $setValueEndTime;
                    // header("location: '".$url."'");
                } else {
                    $data = array('error' => 'sowething went wrong in insert (2)');
                }
            }
        }
    }
}

$page_name = 'dashboard';
?>

<style>
    * {
        box-sizing: border-box;
    }

    .row {
        display: flex;
    }

    .column {
        flex: 50%;
    }

    .column {
        float: left;
        width: 50%;
        padding: 10px;
    }

    /* Clear floats after the columns */
    .row:after {
        content: "";
        display: table;
        clear: both;
    }

    .border {
        border: none;
    }

    .image_box {
        height: 90px;
        width: 145px;
        padding: 5px;
        border: 1px solid #ddd;
        border-radius: 4px;
        margin-bottom: 2px;
    }

    .image_box-view {
        height: 190px;
        width: 245px;
    }

    .w-100 {
        width: 200px;
    }
</style>

<?php include 'header.php'; ?>
<script src="jquery/jquery.min.js"></script>

<script>
    var bid_status = "<?php echo $item['bid_status']; ?>"
    var bidID  = "<?php echo $item['bidID'];?>";
    var itemID  = "<?php echo $item['item_id'];?>";
    var start_time = "<?php echo $endTime; ?>";
    var new_distance = "<?php echo $item["countdown"]; ?>";
    var count_downDate = new Date(start_time).getTime();
    var x = setInterval(function() {
        var now = new Date().getTime();
        var distance = count_downDate - now;
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minute = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        document.getElementById('countDownShow').innerHTML = minute + " : " + seconds;

        if (distance < 0) {
            if (bid_status == 'not sold') {
                $status = 'pending'
                $.ajax({
                    url: 'ows_database/jsQueries.php?setPending='+$status+'&bidID='+bidID+'&itemID='+itemID,
                    cache: false,
                    dataType: 'json',
                })
            }

            clearInterval(x);


            document.getElementById('countDownShow').innerHTML = '';
        }
    }, 1000);
</script>

<div class="content">
    <h2 class="head-h text-white">ITEMS</h2>

    <?php if (isset($_GET['log_error'])) {
        $error_msg = $_GET['log_error']; ?>
        <p class="text-yellow text-center"><?php echo $error_msg; ?> </p>
    <?php } ?>
    <?php if (isset($_GET['log_success'])) {
        $success_msg = $_GET['log_success']; ?>
        <p class="text-green text-center"><?php echo $success_msg; ?></p>
    <?php  } ?>




    <div class="row">
        <div class="column" style="background-color:#aaa;">
            <a href="<?php echo $imageURL; ?>">
                <img class="image_box image_box-view" src="<?php echo $imageURL; ?>" alt="<?php echo $item["item_name"]; ?>">
            </a>
            <div class="pro-left">
                <p>Category: <br>&nbsp;&nbsp;<?php echo $item["icat_name"]; ?></p>
                <p>Status: <br>&nbsp;&nbsp; <span class="<?php echo $icst_badge; ?>"><?php echo $item["icst_name"]; ?></span></p>
            </div>
        </div>
        <div class="column" style="background-color:#bbb;">

            <form action="display.php?itemID=<?php echo $_GET['itemID']; ?>" method="POST">
                <label>My Bid
                    <?php if (!empty($error_msg)) : ?>
                        <span id="abid_msg_error" style="color: red;"> <?php echo $error_msg; ?></span>
                    <?php endif; ?>
                </label>
                <br>

                <table class="border" style="margin-top: 10px;">
                    <tr>
                        <td>
                            <input type="hidden" id="item_id" name="id" value="<?php echo $item["item_id"]; ?>">
                            <input type="hidden" name="itemID" value="<?php echo ($item["item_id"]); ?>">
                            <input type="hidden" name="currBid" value="<?php echo ($item["abid"]); ?>">
                            <input type="hidden" name="price" value="<?php echo ($item["price"]); ?>">
                            <input type="text" id="bid" name="bid" required>
                        </td>
                        <td>
                            <button type="submit" class="button btn" name="bido">Place Bid</button>
                        </td>
                    </tr>
                </table>
            </form>

            <br>

            <?php if (!empty($item['abid'])) : ?>
                <p id='countDownShow'></p>
            <?php endif; ?>
        </div>
    </div>
    <div class="row">
        <table>
            <tr>
                <th>Name</th>
                <td col='3'><?php echo $item["item_name"]; ?></td>
            </tr>
            <tr>
                <th>Starting Price</th>
                <td col='3'><?php echo $item["price"]; ?>/=TSH</td>

            </tr>

            <?php if ($item["abid"] > $item["price"]) : ?>
                <tr>
                    <th>Current Bidding Price</th>
                    <td col='3'><span id="presentBid" value="<?php echo ($item["abid"]); ?>"></span><?php echo ($item["abid"] == 0) ? $item["price"] : $item["abid"]; ?>/=TSH</td>
                </tr>
            <?php endif; ?>
        </table>
    </div>
</div>

<?php include 'footer.php'; ?>

<?php mysqli_close($ows_conn);
