<!-- footer.php -->
<?php include_once 'conts_variable.php'; ?>

		<div class="footer">
    		<p>&copy; 2021 All right reserved DAS</a></p>
        </div>
   </div>
</body>
</html>