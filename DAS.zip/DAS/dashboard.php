<!-- dashboard.php -->
<?php
session_start();
require_once('ows_database/das.php');

if ($_SESSION['loged_in'] != TRUE) {
    header("location: login.php");
}


if ($_SESSION['loged_in_role'] == 1) {
    header("location: ows_admin.php");
}

$userID = $_SESSION['loged_in_user_id'];


if (isset($_POST['sold_item'])) {
    $sold_item = "UPDATE items SET is_sold=1 WHERE item_id='" . $_POST['item_id_sold'] . "'";
    mysqli_query($ows_conn, $sold_item);
}

$page_name = 'dashboard';
?>

<?php include 'header.php'; ?>

<style>
    .image_box {
        height: 90px;
        width: 145px;
        padding: 5px;
        border: 1px solid #ddd;
        border-radius: 4px;
        margin-bottom: 2px;
    }

    .w-100 {
        width: 200px;
    }
</style>

<div class="content">
    <h2 class="head-h text-white">ITEMS</h2>

    <?php if (isset($_GET['log_error'])) {
        $error_msg = $_GET['log_error']; ?>
        <p class="text-yellow text-center"><?php echo $error_msg; ?> </p>
    <?php } ?>
    <?php if (isset($_GET['log_success'])) {
        $success_msg = $_GET['log_success']; ?>
        <p class="text-green text-center"><?php echo $success_msg; ?></p>
    <?php  } ?>


    <?php


    $select_items = "SELECT start_time, countdown, item_name, icst_name,item_img_name, item_id, price, icat_name, IFNULL((SELECT MAX(currentPrice) FROM bid_tb WHERE bid_tb.item_id = items.item_id GROUP BY item_id), 0) abid FROM  items JOIN item_cats ON items.item_cat=item_cats.icat_id JOIN item_cat_status ON items.item_cat_stat=item_cat_status.icst_id JOIN item_image ON items.item_id=item_image.item WHERE items.user != '" . $userID . "' AND itemStatus = 'not sold'";
    $data_items = mysqli_query($ows_conn, $select_items);


    if (mysqli_num_rows($data_items) > 0) :
        while ($item = mysqli_fetch_array($data_items)) {

            $imageURL = 'ows_item_img/' . $item["item_img_name"];

            if ($item["icst_name"] == 'new') {
                $icst_badge = 'bg-green';
            } else if ($item["icst_name"] == 'used') {
                $icst_badge = 'bg-red';
            } else {
                $icst_badge = 'bg-yellow';
            } ?>

            <div class="box">
                <a href="<?php echo $imageURL; ?>">
                    <img class="image_box" src="<?php echo $imageURL; ?>" alt="<?php echo $item["item_name"]; ?>">
                </a>

                <div class="pro-left">
                    <p>Category: <br>&nbsp;&nbsp;<?php echo $item["icat_name"]; ?></p>
                    <p>Status: <br>&nbsp;&nbsp; <span class="<?php echo $icst_badge; ?>"><?php echo $item["icst_name"]; ?></span></p>


                </div>
                <div class="pro-right">
                    <table>
                        <tr>
                            <th>Name</th>
                            <td col='3'><?php echo $item["item_name"]; ?></td>
                        </tr>
                        <tr>
                            <th>Starting Price</th>
                            <td col='3'><?php echo $item["price"]; ?>/=TSH</td>
                        </tr>
                        <tr>
                            <th>Current Bidding Price</th>
                            <td col='3'><span id="presentBid" value="<?php echo ($item["abid"]); ?>"></span><?php echo ($item["abid"] == 0) ? $item["price"] : $item["abid"]; ?>/=TSH</td>
                        </tr>
                    </table>
                    <fieldset>
                        <legend>More</legend>
                        <a href="display.php?itemID=<?php echo $item["item_id"]; ?>" class="button w-100">View Item</a>
                    </fieldset>

                </div>
            </div>
        <?php } ?>

    <?php else : ?>
        <div style="height: 380px;">
            <p style="margin-left: 20px;"> NO ITEM TO BID NOW</p>
        </div>

    <?php endif; ?>
</div>

<?php include 'footer.php'; ?>

<?php mysqli_close($ows_conn);
