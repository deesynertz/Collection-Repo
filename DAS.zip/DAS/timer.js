Document.addeventlistener('DOMcontentloaded', ()=>{

	const timeLeftDispay = Document.querySelector ('#time-left')

	const startbtn = Document.querySelector ('#tstart button')
	 let timeleft =60

	function countdown(){
		setinterval (function(){

			if (timeleft<=0) {
				clearinterval (timeleft=0)
			}

			timeLeftDispay.innerHTML =time-left 
			timeleft-= 1
		},1000 )

	}
	startbtn.addeventlistener('click', countdown)
})
