<!-- about_us.php -->
<?php 
    include 'conts_variable.php'; 

    $page_name = 'about_us';
?>

    <?php include 'header.php';?>

	<div class="content paragraph">
            <h2 class="head-h text-white">ABOUT US</h2>
            <div class="row">
                
        
            <h3 class="sub-head-h">Need to buy or sell anything?</h3>
                
            <p> We are here for you ): </p>

            <p> Easy to use state of the art platform where you can reach customers and sellers around your area easily, to buy anything you want, at a price you can afford.</p>

            <p> Buy and sell anything, from apparels to gadgets. Negotiate the most convenient way to you, for your delivery, communicate directly or indirectly with the other party, and enjoy your experience.</p>
                
        </div>
    </div>

    <?php include 'footer.php';?>