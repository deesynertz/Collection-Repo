<!-- dashboard.php -->
<?php
session_start();
require_once('ows_database/das.php');

if ($_SESSION['loged_in'] != TRUE) {
    header("location: login.php");
}


if ($_SESSION['loged_in_role'] == 1) {
    header("location: ows_admin.php");
}

if (isset($_POST['sold_item'])) {
    $sold_item = "UPDATE items SET is_sold=1 WHERE item_id='" . $_POST['item_id_sold'] . "'";
    mysqli_query($ows_conn, $sold_item);
}

$page_name = 'dashboard';
?>

<?php include 'header.php'; ?>

<style>
    .image_box {
        height: 90px;
        width: 145px;
        padding: 5px;
        border: 1px solid #ddd;
        border-radius: 4px;
        margin-bottom: 2px;
    }
</style>

<div class="content">
    <h2 class="head-h text-white">ITEMS</h2>

    <?php if (isset($_GET['log_error'])) {
        $error_msg = $_GET['log_error']; ?>
        <p class="text-yellow text-center"><?php echo $error_msg; ?> </p>
    <?php } ?>
    <?php if (isset($_GET['log_success'])) {
        $success_msg = $_GET['log_success']; ?>
        <p class="text-green text-center"><?php echo $success_msg; ?></p>
    <?php  } ?>


    <?php
    $user_id = $_SESSION['loged_in_user_id'];
    $select_items = "SELECT start_time, countdown, item_name, icst_name,item_img_name, item_id, price, icat_name, IFNULL((SELECT MAX(currentPrice) FROM bid_tb WHERE bid_tb.item_id = items.item_id GROUP BY item_id), 0) abid, (SELECT endTime FROM bid_tb WHERE bid_tb.item_id = items.item_id GROUP BY item_id) as endTime, (SELECT user_id FROM bid_tb WHERE bid_tb.item_id = items.item_id GROUP BY item_id) as presedBy FROM items JOIN item_cats ON items.item_cat=item_cats.icat_id JOIN item_cat_status ON items.item_cat_stat=item_cat_status.icst_id JOIN item_image ON items.item_id=item_image.item WHERE items.user='$user_id'";
    $data_items = mysqli_query($ows_conn, $select_items);

    while ($item = mysqli_fetch_array($data_items)) { ?>

        <script>
            var bid_status = "<?php echo $item['bid_status']; ?>"
            var bidID = "<?php echo $item['bidID']; ?>";
            var itemID = "<?php echo $item['item_id']; ?>";
            var start_time = "<?php echo $endTime; ?>";
            var new_distance = "<?php echo $item["countdown"]; ?>";
            var count_downDate = new Date(start_time).getTime();
            var x = setInterval(function() {
                var now = new Date().getTime();
                var distance = count_downDate - now;
                var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                var minute = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((distance % (1000 * 60)) / 1000);

                document.getElementById('countDownShow').innerHTML = minute + " : " + seconds;

                if (distance < 0) {
                    if (bid_status == 'not sold') {
                        $status = 'pending'
                        $.ajax({
                            url: 'ows_database/jsQueries.php?setPending=' + $status + '&bidID=' + bidID + '&itemID=' + itemID,
                            cache: false,
                            dataType: 'json',
                        })
                    }

                    clearInterval(x);


                    document.getElementById('countDownShow').innerHTML = '';
                }
            }, 1000);
        </script>
        <?php
        $imageURL = 'ows_item_img/' . $item["item_img_name"];

        if ($item["icst_name"] == 'new') {
            $icst_badge = 'bg-green';
        } else if ($item["icst_name"] == 'used') {
            $icst_badge = 'bg-red';
        } else {
            $icst_badge = 'bg-yellow';
        } ?>

        <div class="box">
            <a href="<?php echo $imageURL; ?>">
                <img class="image_box" src="<?php echo $imageURL; ?>" alt="<?php echo $item["item_name"]; ?>">
            </a>

            <div class="pro-left">
                <p>Category: <br>&nbsp;&nbsp;<?php echo $item["icat_name"]; ?></p>
                <p>Status: <br>&nbsp;&nbsp; <span class="<?php echo $icst_badge; ?>"><?php echo $item["icst_name"]; ?></span></p>

            </div>
            <div class="pro-right">
                <table>
                    <tr>
                        <th>Name</th>
                        <td col='3'><?php echo $item["item_name"]; ?></td>
                    </tr>
                    <tr>
                        <th>Starting Price</th>
                        <td col='3'><?php echo $item["price"]; ?>/=TSH</td>
                    </tr>

                    <th>Current Bidding Price</th>
                    <td col='3'><span id="presentBid" value="<?php echo ($item["abid"]); ?>"></span><?php echo ($item["abid"] == 0) ? $item["price"] : $item["abid"]; ?>/=TSH</td>

                </table>
            </div>
        </div>
    <?php } ?>
</div>

<?php include 'footer.php'; ?>

<?php mysqli_close($ows_conn);
