<?php
session_start();
require_once('ows_database/das.php');

if ($_SESSION['loged_in'] != TRUE) {
	header("location: login.php");
}


if ($_SESSION['loged_in_role'] == 1) {
	header("location: ows_admin.php");
}


$userID = $_SESSION['loged_in_user_id'];

if (isset($_POST['sold_item'])) {
	$sold_item = "UPDATE items SET is_sold=1 WHERE item_id='" . $_POST['item_id_sold'] . "'";
	mysqli_query($ows_conn, $sold_item);
}

$bidListitem = "SELECT start_time, countdown, item_name, phone_on, email,user_address,icst_name,item_img_name, items.item_id, price, icat_name, IFNULL((SELECT MAX(currentPrice) FROM bid_tb WHERE bid_tb.item_id = items.item_id GROUP BY item_id), 0) abid, endTime, bid_tb.user_id  AS presedBy, bid_status, bid_tb.id  AS bidID FROM items JOIN item_cats ON items.item_cat = item_cats.icat_id JOIN item_cat_status ON items.item_cat_stat = item_cat_status.icst_id JOIN item_image ON items.item_id = item_image.item JOIN users ON items.user=users.user_id JOIN bid_tb ON bid_tb.item_id = items.item_id WHERE items.user !='" . $userID . "' AND bid_status != 'not sold'";

$dataBids = mysqli_query($ows_conn, $bidListitem);

$error_msg = '';
if (isset($_POST['bido'])) {

	$url = 'display.php?itemID=' . $_GET['itemID'];

	// check if is bid is less than price
	if ($_POST['price'] >= $_POST['bid']) {
		// message not allowed
		$error_msg = 'Enter higher price!!';
	} else {
		if ($_POST['currBid'] >= $_POST['bid']) {
			// message not allowed
			$error_msg = 'Enter higher price!!';
		} else {
			// good to go
			$bid = $_POST['bid'];

			if (!empty($item['abid'])) {
				// check if present bid is for you
				if ($item['presedBy'] == $userID) {
					// is you the update price
					$setValueEndTime = date_format(date_create(date("D M d, Y G:i:s", strtotime(date("D M d, Y G:i:s")) + (($item['countdown'] * 60) + (60 * 60)))), 'Y-m-d H:i:s');

					$updateAbid = "UPDATE bid_tb SET currentprice='" . $bid . "', endTime = '" . $setValueEndTime . "' WHERE item_id='" . $item['item_id'] . "' AND user_id = '" . $userID . "'";
					$run = mysqli_query($ows_conn, $updateAbid);

					if (mysqli_affected_rows($ows_conn) > 0) {
						$data = array('success' => 'successfully');
						$endTime = $setValueEndTime;
						// header("location: '".$url."'");

					} else {
						$data = array('error' => 'sowething went wrong in update');
					}
				} else {
					// not you insert your bid
					$setValueEndTime = date_format(date_create(date("D M d, Y G:i:s", strtotime(date("D M d, Y G:i:s")) + (($item['countdown'] * 60) + (60 * 60)))), 'Y-m-d H:i:s');
					var_dump('not you insert your bid');
					// var_dump($setValueEndTime);
					$insertAbid = "INSERT INTO bid_tb(item_id,currentPrice,user_id,endTime) VALUE('" . $item['item_id'] . "','" . $bid . "','" . $userID . "','" . $setValueEndTime . "')";
					if (mysqli_query($ows_conn, $insertAbid)) {
						$data = array('success' => 'successfully');
						$endTime = $setValueEndTime;
						// header("location: '".$url."'");

					} else {
						$data = array('error' => 'sowething went wrong in insert (2)');
					}
				}
			} else {

				// insert new bid
				$setValueEndTime = date_format(date_create(date("D M d, Y G:i:s", strtotime(date("D M d, Y G:i:s")) + (($item['countdown'] * 60) + (60 * 60)))), 'Y-m-d H:i:s');
				$insertAbid = "INSERT INTO bid_tb(item_id,currentPrice,user_id,endTime) VALUE('" . $item['item_id'] . "','" . $bid . "','" . $userID . "','" . $setValueEndTime . "')";
				if (mysqli_query($ows_conn, $insertAbid)) {
					$data = array('success' => 'successfully');
					$endTime = $setValueEndTime;
					// header("location: '".$url."'");
				} else {
					$data = array('error' => 'sowething went wrong in insert (2)');
				}
			}
		}
	}
}

$page_name = 'mybid';
?>

<style>
	* {
		box-sizing: border-box;
	}

	.row {
		display: flex;
	}

	.column {
		flex: 50%;
	}

	.column {
		float: left;
		width: 50%;
		padding: 10px;
	}

	/* Clear floats after the columns */
	.row:after {
		content: "";
		display: table;
		clear: both;
	}

	.border {
		border: none;
	}

	.image_box {
		height: 90px;
		width: 145px;
		padding: 5px;
		border: 1px solid #ddd;
		border-radius: 4px;
		margin-bottom: 2px;
	}

	.image_box-view {
		height: 190px;
		width: 245px;
	}

	.w-100 {
		width: 200px;
	}
</style>

<?php include 'header.php'; ?>

<div class="content">
	<h2 class="head-h text-white">ITEMS</h2>

	<?php if (isset($_GET['log_error'])) {
		$error_msg = $_GET['log_error']; ?>
		<p class="text-yellow text-center"><?php echo $error_msg; ?> </p>
	<?php } ?>
	<?php if (isset($_GET['log_success'])) {
		$success_msg = $_GET['log_success']; ?>
		<p class="text-green text-center"><?php echo $success_msg; ?></p>
	<?php  } ?>

	<?php

	if (mysqli_num_rows($dataBids) > 0) :

		while ($item = mysqli_fetch_array($dataBids)) :
			$imageURL = 'ows_item_img/' . $item["item_img_name"];
			if ($item["icst_name"] == 'new') {
				$icst_badge = 'bg-green';
			} else if ($item["icst_name"] == 'used') {
				$icst_badge = 'bg-red';
			} else {
				$icst_badge = 'bg-yellow';
			}
			// add countdown intocurrent dateTime
			if (!empty($item['abid'])) {
				$endTime = $item['endTime'];
			} ?>


			<div class="box">
				<a href="<?php echo $imageURL; ?>">
					<img class="image_box" src="<?php echo $imageURL; ?>" alt="<?php echo $item["item_name"]; ?>">
				</a>

				<div class="pro-left">
					<p>Category: <br>&nbsp;&nbsp;<?php echo $item["icat_name"]; ?></p>
					<p>Status: <br>&nbsp;&nbsp; <span class="<?php echo $icst_badge; ?>"><?php echo $item["icst_name"]; ?></span></p>

				</div>
				<div class="pro-right">
					<table>
						<tr>
							<th>PRODUCT</th>
							<td col='3'><?php echo $item["item_name"]; ?></td>
						</tr>

						<th>WON PRICE</th>
						<td col='3'><span id="presentBid" value="<?php echo ($item["abid"]); ?>"></span><?php echo ($item["abid"] == 0) ? $item["price"] : $item["abid"]; ?>/=TSH</td>

					</table>

					<fieldset>
						<legend>Contact:</legend>
						<p>PAYMENT NO:&nbsp;&nbsp;&nbsp;<strong>0<?php echo $item["phone_on"]; ?></strong></p>
						<p>EMAIL: <strong><?php echo $item["email"]; ?></strong></p>
					</fieldset>

					<fieldset>
						<script src="jquery/jquery.min.js"></script>

						<script>
							var itemID = "<?php echo $item['item_id']; ?>";


							var newbidID = 'bidID' + itemID;
							var newbid_status = 'bid_status' + itemID;
							var newstart_time = 'start_time' + itemID;
							var newnew_distance = 'new_distance' + itemID;
							var newcount_downDate = 'count_downDate' + itemID;
							var newdistance = 'distance' + itemID;

							var newhours = 'hours' + itemID;
							var newminute = 'minute' + itemID;
							var newseconds = 'seconds' + itemID;

							var newx = 'x' + itemID;


							// var bidID  = "<?php //echo $item['bidID'];
																?>";
							// var bid_status = "<?php //echo $item['bid_status']; 
																		?>";
							// var start_time = "<?php //echo $endTime; 
																		?>";
							// var new_distance = "<?php //echo $item["countdown"]; 
																			?>";
							// var count_downDate = new Date(start_time).getTime();

							newbidID = "<?php echo $item['bidID']; ?>";
							newbid_status = "<?php echo $item['bid_status']; ?>";
							newstart_time = "<?php echo $endTime; ?>";
							newnew_distance = "<?php echo $item["countdown"]; ?>";
							newcount_downDate = new Date(start_time).getTime();

							var placeId = 'countDownShow' + itemID;



							newx = setInterval(function() {
								var now = new Date().getTime();
								// var distance = newcount_downDate - now;
								var newdistance = newcount_downDate - now;
								var newhours = Math.floor((newdistance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
								var newminute = Math.floor((newdistance % (1000 * 60 * 60)) / (1000 * 60));
								var newseconds = Math.floor((newdistance % (1000 * 60)) / 1000);

								document.getElementById(placeId).innerHTML = newhours + " : " + newminute + " : " + newseconds;

							}, 1000);
						</script>
						<?php //if (!empty($item['abid'])) : 
						?>
						<p id='countDownShow<?php echo $item['item_id']; ?>'></p>
						<?php //endif; 
						?>
					</fieldset>


				</div>
			</div>
		<?php endwhile; ?>

	<?php else : ?>

		<div style="height: 380px;">
			<p style="margin-left: 20px;"> NO ANY BID FOR NOW!!</p>
		</div>

	<?php endif; ?>
</div>

<?php include 'footer.php'; ?>
<script src="jquery/jquery.min.js"></script>

<?php mysqli_close($ows_conn);
