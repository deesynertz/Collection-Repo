<?php
  require_once('das.php');


  if (isset($_GET['setPending'])) {
    $updateBidTable = "UPDATE bid_tb SET bid_status = '".$_GET['setPending']."' WHERE id='".$_GET['bidID']."'";

    $updateItemsTable = "UPDATE items SET itemStatus = '".$_GET['setPending']."' WHERE item_id ='".$_GET['itemID']."'";

    mysqli_query($ows_conn, $updateBidTable);
    mysqli_query($ows_conn, $updateItemsTable);
  }






?>