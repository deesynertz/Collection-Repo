<!-- conts_variable.php -->
<?php

	$bland = '&#10026;nl&#8520;ne w&#8519;b<span class="brand-end">Store</span>';
	// $bland = '<h1 class="brand">&#10026;&#10072;w&#8519;b<span class="brand-end">Store</span></h1>';
    $brand_slogan = 'we approach service every where';

    // &#10162;



?>