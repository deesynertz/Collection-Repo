<?php

namespace App\Http\Controllers;

use App\Models\Users;
use Illuminate\Http\Request;


class LoginController extends Controller
{
    //login
    protected function loginMethod(Request $req)
    {
        $req->validate([
            'user_id' => 'required',
            'password' => 'required'
        ]);

        $data = Users::join('roles as r', ['r.role_id' => 'users.role_id'])
            ->where(['user_id' => $req->input('user_id'),'password' => $req->input('password')])->get();
            
        if (count($data) > 0) {
            foreach ($data as $userAuth)
                $req->session()->put('userAuth', $userAuth);
                if ($userAuth->role_name == "Admin") {
                    return redirect('/admin');
                } else if ($userAuth->role_name == "Student") {
                    return redirect('/student');
                } else if ($userAuth->role_name == "Lecturer") {
                    return redirect('/lecturer');
                } else if ($userAuth->role_name == "Supervisor") {
                    return redirect('/supervisor');
                } 
        } else {
            return back()->with('error', 'Wrong login detail');
        }
    }

    protected function logoutMethod(Request $req)
    {
        if (session()->has('userAuth')) {
            session()->pull('userAuth');
        }
        return redirect('/');
    }
}
