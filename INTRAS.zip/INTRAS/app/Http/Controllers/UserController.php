<?php

namespace App\Http\Controllers;

use App\Mail\MailProvider;
use App\Models\Field_details;
use App\Models\Files;
use App\Models\Lecturers;
use App\Models\Locations;
use App\Models\Organizations;
use App\Models\Programs;
use App\Models\Students;
use App\Models\Supervisions;
use App\Models\Users;
use Facade\FlareClient\Http\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\VarDumper\Cloner\Data;

class UserController extends Controller
{
    // Admin
    function administratorRoute(Request $req) {
        $data['students_all'] = Users::join('students as st', ['st.student_id' => 'Users.user_id'])
        ->join('programs as pr', ['pr.program_id' => 'st.program'])
        ->join('department as dp', ['dp.department_id' => 'pr.department_id'])
        ->where(['role_id' => 3, ])
        ->get();
        
        $data['lecturer_all'] = Lecturers::join('users as u', ['u.user_id' => 'lecturers.lecturer_id'])
        ->join('department as dp', ['dp.department_id' => 'lecturers.department_id'])->get(); //
        // ->where(['user_id' => 'users.user_id'])all();

        return view('admin/index',$data);
    }

    public function alocateRoute(Request $req)
    {
        $notAlocated = 'not allocated';
        $data['field_details'] = Field_details::join('locations as l', ['l.location_id' => 'field_details.location_id'])
        ->where(['field_status' => $notAlocated])
        ->get();

        $data['lecturers'] = Lecturers::join('locations as l', ['l.location_id' => 'lecturers.location_id'])->get();

        return view('admin/alocate', $data);
    }

    public function submitAlocationRoute(Request $req) {
        $supervisions = new Supervisions;
        $supervisions->field_id          = $req->input('field_id');
        $supervisions->lecturer_id        = $req->input('lecturer_id');
        $cb = $supervisions->save();

        if ($cb) {
            Field_details::where(['id' => $req->input('field_id')])
            ->update(['field_status'=> 'allocated']);
            $req->session()->flash('alert-success', 'successully allocated');
            return redirect('/admin/alocate');
        } else {
            $req->session()->flash('alert-danger', 'Allocation Failed something went wrong');
            return redirect('/admin/alocate');
        }
        
    }


    // Lecturer
    function lecturerRoute(Request $req) {
        $data['user_id'] = session('userAuth')['user_id'];
        $data['students_all'] = Supervisions::select('supervision_id', 'fd.student_id', 'firstname', 'middlename', 'lastname', 'phonenumber', 'file_name', 'organization_name', 'program_name', 'location_name','address')
        ->leftJoin('field_details as fd', ['fd.id' => 'supervisions.field_id'])
        ->leftJoin('files as fl', ['fd.id' => 'fl.field_id'])
        ->join('students as st', ['st.student_id' => 'fd.student_id'])
        ->join('users as user', ['user.user_id' => 'st.student_id'])
        ->join('programs as pg', ['st.program' => 'pg.program_id'])
        ->join('organizations as og', ['og.organization_id' => 'fd.organization_id'])
        ->join('locations as l', ['l.location_id' => 'fd.location_id'])
        ->where(['supervisions.lecturer_id'=> session("userAuth")['user_id']])
        ->get();
        return view('lecturer/index',$data);
    }

    public function lecturerSendLinkRoute(Request $req)
    {
        //  GET INFO BY supervision_id
        $student_detail = Supervisions::select('field_id', 'fd.student_id', 'firstname', 'middlename', 'lastname', 'phonenumber', 'email', 'organization_name', 'program_name')
        ->join('field_details as fd', ['fd.id' => 'supervisions.field_id'])
        ->join('students as st', ['st.student_id' => 'fd.student_id'])
        ->join('programs as pg', ['st.program' => 'pg.program_id'])
        ->join('users as user', ['user.user_id' => 'st.student_id'])
        ->join('organizations as og', ['og.organization_id' => 'fd.organization_id'])
        ->where(['supervision_id'=> $req->input('supervision_id')])
        ->get();


        // SET LINK 
        $link = 'http://127.0.0.1:8000';

        // SET VARIABLES
        foreach($student_detail as $row)
            // STUDENT INFO
            $phone   = $row['phonenumber'];
            $name    =   $row['firstname']." ".$row['middlename']." ".$row['lastname'];
            $program =   $row['program_name'];

            // LOCAL SUPERVISOR
            $username   =   $row['email'];
            $password   =   '123456';
            $sendTo     =   $row['email'];

        
        // SET EMAIL
        $details = [
            'title' => "INTRAS Login Cridentials",
            'body'  => "Please user given cridential to login in our system in order to send evaluation Report of MU-Student $name ($program) - ($phone) atend to your premise.",
            'username'=> $username,
            'password'=> $password,
            'link'=> $link,
        ];

        Mail::to($sendTo)->send(new MailProvider($details));

        // INSERT USER INTO user table
        $user = new Users;
        $user->user_id      = $username;
        $user->user_email   = $username;
        $user->password     = $password;
        $user->role_id      = 4;
        $cb = $user->save();

        if ($cb) {
                // CALLBACK
            $data['success'] = 'Email sent';

            $notfication = array(
                'message' =>'emailsent', 'Email has been sent successfully ',
                'alert-type' => 'success'
            );
        }

        return redirect('/lecturer');
    }

    // Students
    public function studentsRoute(Request $req){
        $userID = session('userAuth')['user_id'];
        $exist = Field_details::where(['student_id' => session('userAuth')['user_id']])
        ->get('student_id');
        foreach($exist as $row)
            $data['useridExist'] = $userID;

        if (count($exist) > 0) {

            $data['profile'] = Students::join('programs as pg', ['program' => 'pg.program_id'])
            ->join('field_details as fd', ['fd.student_id' => 'students.student_id'])
            ->join('users as u', ['u.user_id' => 'students.student_id'])
            ->join('organizations as og', ['og.organization_id' => 'fd.organization_id'])
            ->where(['students.student_id' => session('userAuth')['user_id']])
            ->first();

            // var_dump($data['profile'] );

            return view('students/index',$data);
        } else {
            return redirect('student-fillForm');
        }
    }

    public function fillFormRoute(Request $req) {
        $userID = session('userAuth')['user_id'];
        $exist = Field_details::where(['student_id' => $userID])->get('student_id');

        $data['useridExist'] = $userID;

        $data['programs'] = Programs::all();
        $data['organizations'] = Organizations::all();
        $data['locations'] = Locations::all();

        if (count($exist) > 0) {
            return redirect('/student');
        } else {
            return view('students/fieldForm', $data);
        }
    }

    public function submitFormRoute(Request $req)
    {
        $students = new Students;
        $students->student_id       = session('userAuth')['user_id'];
        $students->program          = $req->input('program_id');
        $students->firstname        = $req->input('firstname');
        $students->middlename       = $req->input('middlename');
        $students->lastname         = $req->input('lastname');
        $cb = $students->save();

        if ($cb) {
            $supervision_detail = new Field_details;
            $supervision_detail->student_id         =   session('userAuth')['user_id'];
            $supervision_detail->organization_id    =   $req->input('organization_id');
            $supervision_detail->location_id        =   $req->input('location_id');
            $supervision_detail->email              =   $req->input('organization_email');
            $supervision_detail->address            =   $req->input('organization_address');
            $responce = $supervision_detail->save();

            if ($responce) {
                return redirect('/student');
            }
        }else {
            return redirect('student-fillForm');

        }
    }

    // Supervisor
    function supervisorRoute(Request $req) {
        $data['student_detail'] = Supervisions::select('supervisions.field_id', 'fd.student_id', 'firstname', 'middlename', 'lastname', 'phonenumber', 'email','user_email' ,'organization_name', 'program_name', 'file_name')
        ->join('field_details as fd', ['fd.id' => 'supervisions.field_id'])
        ->join('students as st', ['st.student_id' => 'fd.student_id'])
        ->join('programs as pg', ['st.program' => 'pg.program_id'])
        ->join('users as user', ['user.user_id' => 'st.student_id'])
        ->join('organizations as og', ['og.organization_id' => 'fd.organization_id'])
        ->leftJoin('files as f', ['f.field_id' => 'fd.id'])
        ->where(['fd.email'=> session("userAuth")['user_id']])
        ->get();

        return view('supervisor/index',$data);

    }

    public function supervisorSendReportRoute(Request $req)
    {
        // {files} file_id	file_name	field_id	file_path

        // $req->validate([
        //     'document' => 'required|file|mimes:doc,docx,pdf',
        // ]);

        $field_id = $req->input('field_id');
        $filePath  = $req->file('document');
        // $student_id = substr($req->input('student_id'), 6);
        $newFileName = time().'.'.$filePath->extension();
        $filePath->move(public_path('documents'),$newFileName);

        $files = new Files;
        $files->field_id        = $field_id;
        $files->file_name       = $newFileName;
        $files->save();

        return back()->with('report_success', 'Report has been sent');
    }

    public function downloadFile($file_name)
    {
        // $file = Files::where('file_name', $file_name)->firstOrFail();

        // // $file_path = storage_path().'/documents'.$file->file_name;
        // $file_path = Storage::disk('public/documents')->get($file->file_name);


        // return (new Response($file_path, 200));
        // // return Response::download($file_path, $file->file_name, [
        // //     'Content-Length: ',filesize($file_path)
        // // ]);
    }

}
