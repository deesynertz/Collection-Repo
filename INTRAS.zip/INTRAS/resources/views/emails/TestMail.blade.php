<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>INTRAS</title>
</head>

<body>
  <h2>{{$details['title']}}</h2>
  <p>Hello,</p>
  <p>{{$details['body']}} </p>
  <p>Username: {{$details['username']}} <br> Password: {{$details['password']}}</p>
  <br>
  <p>System Link: {{$details['link']}}</p>
  <p>Thanks you.</p>
</body>

</html>