<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" type="text/css" href="">
  <title>INTRAS</title>
  <style>
    body {
      margin: 0px;
      padding-bottom: 5px;
      background-size: cover;
      box-sizing: border-box;
      padding-right: 200px;
      /*background-color: rgb(239,178,33);*/
      background-image: url(images/mzumbe.PNG);
    }

    .one {
      padding-left: 80px;
      text-align: left;
      padding-top: 6%;
      padding-bottom: 10px;
      width: 55%;
      color: #000000;
      font-size: 15px;
      font-family: serif;
      color: #1e0d0f;
      color: #fff;
      text-shadow: 1px 1px 0px #000;
    }

    .wrapper {
      float: right;
      width: 35%;
      height: 100%;
      margin: 2% auto;
      box-sizing: border-box;
      text-align: center;
      outline: none;
      font-family: sans-serif;
      font-size: 16px;
      padding-top: 8.5%;
      padding-bottom: 7%;
      padding-left: 80px;
      position: relative;
      box-shadow: 8px 8px 50px #193465;
      display: flex;
      margin-top: 58px;
      border-radius: 10px;
      background-color: lavender;


    }

    .wrapper input {
      width: 85%;
      margin-bottom: 20px;
    }

    .wrapper input[type=text],
    .wrapper input[type=password] {
      border: none;
      border-bottom: 2px solid #ddd;
      background: transparent;
      height: 30px;
      font-size: 16px;
      opacity: 1;
      color: #ccc;
    }

    .wrapper input[type=submit] {
      height: 40px;
      background: #3268ca;
      color: #fff;
      font-size: 12px;
      font-weight: bold;
      width: 80%;
      border-radius: 10px;

    }

    .wrapper input[type=submit]:hover {
      cursor: pointer;
    }

    .wrapper a {
      text-decoration: none;
      color: #1f417e;
      font-size: 14px;
    }

    h1 {
      text-align: center;
      font-family: helvetica;
      color: white;
      text-shadow: 2px 2px 1px #000;

    }

    h4 {
      text-shadow: 0px 1px 1px #000;
    }

    img {
      width: 130px;
      height: 120px;
      align-content: centre;
    }
  </style>
</head>
<body>
  <div class="wrapper">
    <form action="/" method="POST">
      @csrf
      <img src="{{ URL::to('images/logo.png') }}">
      <h4 style="color:#3268ca; ">Please login with credentials</h4>

      <span style="color:red">@error('user_id'){{$message}}@enderror</span>
      <input type="text" name="user_id" placeholder="Username"><br>

      <span style="color:red">@error('password'){{$message}}@enderror</span>
      <input type="password" name="password" placeholder="Password" maxlength="100"><br>

      <input type="submit" name="" value="LOGIN"><br>
      <a href="">Forgot password?</a>

      @if($message=Session::get("error"))

      <strong>{{$message}}</strong>
      @endif
    </form>
  </div>

  <div class="one">
    <h1><strong>MU-INTRAS</strong></h1>
</body>
</html>