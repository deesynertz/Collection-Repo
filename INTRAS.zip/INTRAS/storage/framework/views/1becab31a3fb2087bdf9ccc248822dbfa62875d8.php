<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Doc</title>
</head>

<body>

<?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <h1><?php echo e($row['title']); ?></h1>
  <p><?php echo e($row['body']); ?></p>
  <p>Thank you</p>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>

</html><?php /**PATH F:\SERVERS\xampp\htdocs\INTRAS\resources\views//emails/TestMail.blade.php ENDPATH**/ ?>