<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>INTRAS</title>
</head>

<body>
  <h2><?php echo e($details['title']); ?></h2>
  <p>Hello,</p>
  <p><?php echo e($details['body']); ?> </p>
  <p>Username: <?php echo e($details['username']); ?> <br> Password: <?php echo e($details['password']); ?></p>
  <br>
  <p>System Link: <?php echo e($details['link']); ?></p>
  <p>Thanks you.</p>
</body>

</html><?php /**PATH F:\SERVERS\xampp\htdocs\INTRAS\resources\views/emails/TestMail.blade.php ENDPATH**/ ?>