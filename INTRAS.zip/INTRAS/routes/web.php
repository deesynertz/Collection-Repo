<?php

use App\Http\Controllers\LoginController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*
|--------------------------------------------------------------------------
| Web Routes Direct
|--------------------------------------------------------------------------
*/

Route::view('/','login');

/*
|--------------------------------------------------------------------------
| Web Routes BY Controller
|--------------------------------------------------------------------------
*/

Route::post('/',[LoginController::class,'loginMethod']);

// Administrator Route
Route::get('/admin',[UserController::class,'administratorRoute']);
Route::get('/admin/alocate',[UserController::class,'alocateRoute']);
Route::post('/admin/admin-alocate-form',[UserController::class,'submitAlocationRoute']);

// Lecturer Route
Route::get('/lecturer',[UserController::class,'lecturerRoute']);
Route::post('/sendLink',[UserController::class,'lecturerSendLinkRoute']);

// Students Route
Route::get('/student',[UserController::class,'studentsRoute']);
Route::get('/student-fillForm',[UserController::class,'fillFormRoute']);
Route::post('/student-sendForm',[UserController::class,'submitFormRoute']);

// Supervisor Route
Route::get('/supervisor',[UserController::class,'supervisorRoute']);
Route::post('/sendReport',[UserController::class,'supervisorSendReportRoute'])->name('files.store');



Route::get('file/{file_name}/download',[UserController::class,'downloadFile'])->name('file.download');


// Logout
Route::get('/logout',[LoginController::class,'logoutMethod']);


